import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

const myths = [
  {
    myth: 'Carbs are bad for you',
    fact: 'Carbohydrates are an essential macronutrient. The key is choosing complex carbs like whole grains, oats, and vegetables over simple sugars.',
  },
  {
    myth: 'You need to do cardio to lose weight',
    fact: 'While cardio helps, weight loss is primarily driven by caloric deficit. Strength training and proper nutrition are equally important.',
  },
  {
    myth: 'More protein = More muscle',
    fact: 'Protein is necessary but not sufficient. You need adequate protein (0.7-1g per lb), resistance training, and proper recovery.',
  },
  {
    myth: 'You should train the same muscle every day',
    fact: 'Muscles grow during rest, not during training. Most muscles need 48 hours recovery between intense sessions.',
  },
];

export default function MythVsFact() {
  return (
    <div style={{ minHeight: '100vh' }}>
      <section style={{ padding: '4rem 0', background: 'rgba(22, 27, 34, 0.5)', textAlign: 'center' }}>
        <div className="container">
          <h1>Myth vs Fact</h1>
          <p style={{ color: '#b0b0b0', marginTop: '1rem', maxWidth: '600px', margin: '1rem auto 0' }}>
            Separating fitness facts from fiction with science-backed information.
          </p>
        </div>
      </section>

      <section style={{ padding: '4rem 0' }}>
        <div className="container" style={{ maxWidth: '900px' }}>
          {myths.map((item, i) => (
            <div key={i} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '2rem', marginBottom: '2rem' }}>
              <div style={{ background: 'rgba(231, 76, 60, 0.1)', padding: '2rem', borderRadius: '1rem', borderLeft: '4px solid #E74C3C' }}>
                <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.85rem', fontWeight: 700, marginBottom: '1rem', padding: '0.5rem 1rem', borderRadius: '0.75rem', background: 'rgba(231, 76, 60, 0.2)', color: '#FF6B6B', width: 'fit-content' }}>
                  <i className="fas fa-times-circle"></i> Myth
                </div>
                <h3 style={{ marginBottom: '1rem', fontSize: '1.1rem' }}>{item.myth}</h3>
              </div>
              <div style={{ background: 'rgba(46, 204, 113, 0.1)', padding: '2rem', borderRadius: '1rem', borderLeft: '4px solid #2ECC71' }}>
                <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.85rem', fontWeight: 700, marginBottom: '1rem', padding: '0.5rem 1rem', borderRadius: '0.75rem', background: 'rgba(46, 204, 113, 0.2)', color: '#51CF66', width: 'fit-content' }}>
                  <i className="fas fa-check-circle"></i> Fact
                </div>
                <h3 style={{ marginBottom: '1rem', fontSize: '1.1rem' }}>The Truth</h3>
                <p style={{ color: '#b0b0b0', lineHeight: 1.6, margin: 0 }}>{item.fact}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section style={{ padding: '4rem 0', background: 'rgba(22, 27, 34, 0.5)', textAlign: 'center' }}>
        <div className="container">
          <h2 style={{ marginBottom: '1rem' }}>Ready to Shop Safely?</h2>
          <p style={{ fontSize: '1.05rem', color: '#b0b0b0', marginBottom: '2rem', maxWidth: '600px', margin: '0 auto 2rem' }}>
            Use our AI consultation to get personalized recommendations based on science-backed information.
          </p>
          <Link href="/ai-consultation" style={{ textDecoration: 'none' }}>
            <Button className="btn-primary">Start AI Consultation</Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
