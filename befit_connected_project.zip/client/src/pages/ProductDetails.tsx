import React, { useState } from 'react';
import { Link, useRoute } from 'wouter';
import { Button } from '@/components/ui/button';
import { useStore } from '@/contexts/StoreContext';
import { toast } from 'sonner';

export default function ProductDetails() {
  const [, params] = useRoute('/product/:id');
  const { products, addToCart } = useStore();
  const [quantity, setQuantity] = useState(1);
  const [mainImage, setMainImage] = useState(0);

  const productId = parseInt(params?.id || '1');
  const product = products.find(p => p.id === productId);
  const relatedProducts = products.filter(p => p.category === product?.category && p.id !== productId).slice(0, 4);

  if (!product) {
    return (
      <div style={{ minHeight: '80vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <h1>Product Not Found</h1>
          <Link href="/shop" style={{ textDecoration: 'none' }}>
            <Button>Back to Shop</Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart({ id: product.id, name: product.name, price: product.price, image: product.image, quantity });
    toast.success(`${product.name} added to cart!`);
  };

  const discount = product.oldPrice ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100) : 0;
  const oldPrice = product.oldPrice || 0;

  return (
    <div style={{ minHeight: '100vh', padding: '3rem 0' }}>
      <div className="container">
        <Link href="/shop" style={{ textDecoration: 'none', color: '#b0b0b0', marginBottom: '2rem', display: 'inline-block' }}>
          <i className="fas fa-arrow-left" style={{ marginRight: '0.5rem' }}></i> Back to Shop
        </Link>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '3rem', alignItems: 'start' }}>
          {/* Image Section */}
          <div>
            <div style={{ width: '100%', borderRadius: '1.25rem', overflow: 'hidden', marginBottom: '1rem', background: '#1A1F26', aspectRatio: '1' }}>
              <img src={product.image} alt={product.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            </div>
            <div style={{ display: 'flex', gap: '0.75rem' }}>
              {[0, 1, 2, 3].map((i) => (
                <div
                  key={i}
                  onClick={() => setMainImage(i)}
                  style={{
                    width: '80px',
                    height: '80px',
                    borderRadius: '0.75rem',
                    overflow: 'hidden',
                    cursor: 'pointer',
                    border: mainImage === i ? '2px solid #FF5733' : '2px solid rgba(255, 255, 255, 0.1)',
                    transition: 'all 0.2s',
                  }}
                >
                  <img src={product.image} alt={`View ${i + 1}`} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                </div>
              ))}
            </div>
          </div>

          {/* Info Section */}
          <div>
            <h1 style={{ marginBottom: '1rem' }}>{product.name}</h1>

            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem' }}>
              <div style={{ display: 'flex', gap: '0.25rem' }}>
                {[...Array(5)].map((_, i) => (
                  <i key={i} className="fas fa-star" style={{ color: i < Math.floor(product.rating || 0) ? '#F39C12' : '#808080', fontSize: '1rem' }}></i>
                ))}
              </div>
              <span style={{ color: '#b0b0b0', fontSize: '0.9rem' }}>{product.rating} ({product.reviews} reviews)</span>
            </div>

            <div style={{ display: 'flex', alignItems: 'baseline', gap: '1rem', marginBottom: '1.5rem' }}>
              <span style={{ fontSize: '2rem', fontWeight: 700, color: '#FF5733' }}>${product.price.toFixed(2)}</span>
              {product.oldPrice && (
                <>
                  <span style={{ fontSize: '1.2rem', color: '#808080', textDecoration: 'line-through' }}>${product.oldPrice.toFixed(2)}</span>
                  <span style={{ background: '#E74C3C', color: 'white', padding: '0.25rem 0.75rem', borderRadius: '0.5rem', fontSize: '0.85rem', fontWeight: 600 }}>-{discount}%</span>
                </>
              )}
            </div>

            <div style={{ background: 'rgba(46, 204, 113, 0.1)', border: '1px solid #2ECC71', padding: '1rem', borderRadius: '1rem', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <i className="fas fa-check-circle" style={{ fontSize: '2rem', color: '#2ECC71' }}></i>
              <div>
                <div style={{ fontWeight: 700, color: '#2ECC71' }}>Safety Score: {product.safetyScore}%</div>
                <div style={{ fontSize: '0.9rem', color: '#b0b0b0' }}>Third-party tested and verified</div>
              </div>
            </div>

            {product.tags && product.tags.length > 0 && (
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '2rem' }}>
                {product.tags.map((tag, i) => (
                  <span key={i} style={{ background: 'rgba(255, 87, 51, 0.1)', color: '#FF5733', padding: '0.5rem 1rem', borderRadius: '2rem', fontSize: '0.85rem', border: '1px solid rgba(255, 87, 51, 0.2)' }}>
                    {tag}
                  </span>
                ))}
              </div>
            )}

            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', border: '1px solid rgba(255, 255, 255, 0.1)', borderRadius: '0.5rem', overflow: 'hidden' }}>
                <button onClick={() => setQuantity(Math.max(1, quantity - 1))} style={{ background: '#161B22', border: 'none', color: '#fff', width: '40px', height: '40px', cursor: 'pointer' }}>-</button>
                <input type="number" value={quantity} onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))} style={{ width: '60px', textAlign: 'center', background: 'none', border: 'none', color: '#fff', fontWeight: 600 }} />
                <button onClick={() => setQuantity(quantity + 1)} style={{ background: '#161B22', border: 'none', color: '#fff', width: '40px', height: '40px', cursor: 'pointer' }}>+</button>
              </div>
              <span style={{ color: '#b0b0b0' }}>In Stock</span>
            </div>

            <div style={{ display: 'flex', gap: '1rem', marginBottom: '2rem', flexWrap: 'wrap' }}>
              <Button onClick={handleAddToCart} style={{ flex: 1 }} className="btn-primary">Add to Cart</Button>
              <Button variant="outline" style={{ flex: 1 }}>Add to Wishlist</Button>
            </div>

            <div style={{ marginTop: '2rem', paddingTop: '2rem', borderTop: '1px solid rgba(255, 255, 255, 0.1)' }}>
              <h3 style={{ marginBottom: '1rem' }}>About this product</h3>
              <p style={{ lineHeight: 1.8, marginBottom: '1rem', color: '#b0b0b0' }}>{product.description}</p>
              <h4 style={{ marginBottom: '0.5rem' }}>Key Benefits:</h4>
              <ul style={{ listStyle: 'none', margin: '1rem 0' }}>
                {['Third-party tested', 'Science-backed formula', 'Premium quality ingredients', 'Recommended by experts'].map((benefit, i) => (
                  <li key={i} style={{ padding: '0.5rem 0', paddingLeft: '1.5rem', position: 'relative' }}>
                    <span style={{ position: 'absolute', left: 0, color: '#2ECC71', fontWeight: 'bold' }}>✓</span>
                    {benefit}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {relatedProducts.length > 0 && (
          <div style={{ marginTop: '4rem', paddingTop: '2rem', borderTop: '1px solid rgba(255, 255, 255, 0.1)' }}>
            <h2 style={{ marginBottom: '2rem' }}>Related Products</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '1.5rem' }}>
              {relatedProducts.map((p) => (
                <Link key={p.id} href={`/product/${p.id}`} style={{ textDecoration: 'none', color: 'inherit' }}>
                  <div
                    style={{ background: '#1A1F26', borderRadius: '1rem', overflow: 'hidden', border: '1px solid rgba(255, 255, 255, 0.1)', cursor: 'pointer', transition: 'all 0.3s' }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.borderColor = '#FF5733';
                      e.currentTarget.style.transform = 'translateY(-5px)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                      e.currentTarget.style.transform = 'translateY(0)';
                    }}
                  >
                    <img src={p.image} alt={p.name} style={{ width: '100%', height: '200px', objectFit: 'cover' }} />
                    <div style={{ padding: '1rem' }}>
                      <h4 style={{ marginBottom: '0.5rem', fontSize: '1rem' }}>{p.name}</h4>
                      <div style={{ color: '#FF5733', fontWeight: 700 }}>${p.price.toFixed(2)}</div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
