import React, { useState } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { useStore } from '@/contexts/StoreContext';
import { toast } from 'sonner';

export default function Payment() {
  const { getCartTotal, clearCart } = useStore();
  const [cardData, setCardData] = useState({
    cardNumber: '',
    cardHolder: '',
    expiryDate: '',
    cvv: '',
  });
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    let processedValue = value;

    if (field === 'cardNumber') {
      // Remove spaces and limit to 16 digits
      processedValue = value.replace(/\s/g, '').slice(0, 16);
      // Add spaces every 4 digits for display
      processedValue = processedValue.replace(/(\d{4})/g, '$1 ').trim();
    } else if (field === 'expiryDate') {
      // Format as MM/YY
      processedValue = value.replace(/\D/g, '').slice(0, 4);
      if (processedValue.length >= 2) {
        processedValue = processedValue.slice(0, 2) + '/' + processedValue.slice(2);
      }
    } else if (field === 'cvv') {
      // Limit to 3 digits
      processedValue = value.replace(/\D/g, '').slice(0, 3);
    }

    setCardData(prev => ({ ...prev, [field]: processedValue }));
  };

  const validateCardData = () => {
    // Validate card number (16 digits)
    const cardNumberOnly = cardData.cardNumber.replace(/\s/g, '');
    if (cardNumberOnly.length !== 16) {
      toast.error('Card number must be 16 digits');
      return false;
    }

    // Validate card holder name
    if (!cardData.cardHolder || cardData.cardHolder.trim().length < 3) {
      toast.error('Card holder name must be at least 3 characters');
      return false;
    }

    // Validate expiry date (MM/YY format)
    if (!cardData.expiryDate || cardData.expiryDate.length !== 5) {
      toast.error('Expiry date must be in MM/YY format');
      return false;
    }

    const [month, year] = cardData.expiryDate.split('/');
    const monthNum = parseInt(month);
    if (monthNum < 1 || monthNum > 12) {
      toast.error('Invalid month in expiry date');
      return false;
    }

    // Validate CVV (3 digits)
    if (cardData.cvv.length !== 3) {
      toast.error('CVV must be 3 digits');
      return false;
    }

    return true;
  };

  const handlePayment = async () => {
    if (!validateCardData()) {
      return;
    }

    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      setPaymentSuccess(true);
      toast.success('Payment processed successfully!');
      clearCart();
      setTimeout(() => {
        window.location.href = '/';
      }, 2000);
    }, 2000);
  };

  if (paymentSuccess) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', textAlign: 'center', padding: '2rem' }}>
        <div style={{ background: '#1A1F26', padding: '3rem', borderRadius: '1rem', border: '1px solid rgba(255, 255, 255, 0.1)', maxWidth: '500px' }}>
          <div style={{ fontSize: '3rem', color: '#2ECC71', marginBottom: '1rem' }}>
            <i className="fas fa-check-circle"></i>
          </div>
          <h1 style={{ marginBottom: '1rem' }}>Payment Successful!</h1>
          <p style={{ color: '#b0b0b0', marginBottom: '2rem' }}>Your order has been placed and you will receive a confirmation email shortly.</p>
          <Link href="/" style={{ textDecoration: 'none' }}>
            <Button className="btn-primary">Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', padding: '3rem 0' }}>
      <div className="container" style={{ maxWidth: '700px' }}>
        <h1 style={{ marginBottom: '0.5rem', textAlign: 'center' }}>
          Complete Your <span style={{ color: '#FF5733' }}>Payment</span>
        </h1>
        <p style={{ textAlign: 'center', color: '#b0b0b0', marginBottom: '3rem' }}>Secure payment processing with encryption</p>

        <div style={{ background: '#1A1F26', padding: '2.5rem', borderRadius: '1rem', border: '1px solid rgba(255, 255, 255, 0.1)', marginBottom: '2rem' }}>
          {/* Order Summary */}
          <div style={{ background: '#161B22', padding: '1.5rem', borderRadius: '0.75rem', marginBottom: '2.5rem' }}>
            <h3 style={{ marginBottom: '1rem', fontSize: '0.95rem', color: '#b0b0b0' }}>ORDER SUMMARY</h3>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
              <span>Amount to Pay:</span>
              <span style={{ fontSize: '1.5rem', fontWeight: 700, color: '#FF5733' }}>${getCartTotal().toFixed(2)}</span>
            </div>
            <div style={{ fontSize: '0.85rem', color: '#b0b0b0', marginTop: '0.5rem' }}>
              <i className="fas fa-info-circle" style={{ marginRight: '0.5rem' }}></i>
              All transactions are secure and encrypted
            </div>
          </div>

          {/* Card Information Section */}
          <div style={{ marginBottom: '2.5rem' }}>
            <h3 style={{ marginBottom: '1.5rem', fontSize: '1.1rem', fontWeight: 700 }}>Card Information</h3>

            {/* Card Number */}
            <div style={{ marginBottom: '1.5rem' }}>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, fontSize: '0.95rem' }}>
                Card Number <span style={{ color: '#FF5733' }}>*</span>
              </label>
              <div style={{ position: 'relative' }}>
                <input
                  type="text"
                  placeholder="1234 5678 9012 3456"
                  value={cardData.cardNumber}
                  onChange={(e) => handleInputChange('cardNumber', e.target.value)}
                  maxLength={19}
                  style={{
                    width: '100%',
                    padding: '0.75rem 0.75rem 0.75rem 2.75rem',
                    background: '#161B22',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    borderRadius: '0.5rem',
                    color: '#fff',
                    fontSize: '1rem',
                    fontFamily: 'monospace',
                    transition: 'border-color 0.2s',
                  }}
                  onFocus={(e) => {
                    e.currentTarget.style.borderColor = '#FF5733';
                  }}
                  onBlur={(e) => {
                    e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                  }}
                />
                <i className="fas fa-credit-card" style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: '#b0b0b0' }}></i>
              </div>
              <p style={{ fontSize: '0.8rem', color: '#b0b0b0', marginTop: '0.25rem' }}>
                {cardData.cardNumber.length > 0 ? `${cardData.cardNumber.replace(/\s/g, '').length}/16 digits` : 'Enter 16-digit card number'}
              </p>
            </div>

            {/* Card Holder Name */}
            <div style={{ marginBottom: '1.5rem' }}>
              <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, fontSize: '0.95rem' }}>
                Card Holder Name <span style={{ color: '#FF5733' }}>*</span>
              </label>
              <input
                type="text"
                placeholder="John Doe"
                value={cardData.cardHolder}
                onChange={(e) => handleInputChange('cardHolder', e.target.value)}
                style={{
                  width: '100%',
                  padding: '0.75rem',
                  background: '#161B22',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '0.5rem',
                  color: '#fff',
                  fontSize: '1rem',
                  transition: 'border-color 0.2s',
                }}
                onFocus={(e) => {
                  e.currentTarget.style.borderColor = '#FF5733';
                }}
                onBlur={(e) => {
                  e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                }}
              />
              <p style={{ fontSize: '0.8rem', color: '#b0b0b0', marginTop: '0.25rem' }}>Name as it appears on card</p>
            </div>

            {/* Expiry Date and CVV */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1.5rem' }}>
              <div>
                <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, fontSize: '0.95rem' }}>
                  Expiry Date <span style={{ color: '#FF5733' }}>*</span>
                </label>
                <input
                  type="text"
                  placeholder="MM/YY"
                  value={cardData.expiryDate}
                  onChange={(e) => handleInputChange('expiryDate', e.target.value)}
                  maxLength={5}
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    background: '#161B22',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    borderRadius: '0.5rem',
                    color: '#fff',
                    fontSize: '1rem',
                    fontFamily: 'monospace',
                    transition: 'border-color 0.2s',
                  }}
                  onFocus={(e) => {
                    e.currentTarget.style.borderColor = '#FF5733';
                  }}
                  onBlur={(e) => {
                    e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                  }}
                />
                <p style={{ fontSize: '0.8rem', color: '#b0b0b0', marginTop: '0.25rem' }}>MM/YY format</p>
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, fontSize: '0.95rem' }}>
                  CVV <span style={{ color: '#FF5733' }}>*</span>
                </label>
                <div style={{ position: 'relative' }}>
                  <input
                    type="text"
                    placeholder="123"
                    value={cardData.cvv}
                    onChange={(e) => handleInputChange('cvv', e.target.value)}
                    maxLength={3}
                    style={{
                      width: '100%',
                      padding: '0.75rem 0.75rem 0.75rem 2.75rem',
                      background: '#161B22',
                      border: '1px solid rgba(255, 255, 255, 0.1)',
                      borderRadius: '0.5rem',
                      color: '#fff',
                      fontSize: '1rem',
                      fontFamily: 'monospace',
                      transition: 'border-color 0.2s',
                    }}
                    onFocus={(e) => {
                      e.currentTarget.style.borderColor = '#FF5733';
                    }}
                    onBlur={(e) => {
                      e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                    }}
                  />
                  <i className="fas fa-question-circle" style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: '#b0b0b0', cursor: 'help' }} title="3-digit security code on back of card"></i>
                </div>
                <p style={{ fontSize: '0.8rem', color: '#b0b0b0', marginTop: '0.25rem' }}>Back of card</p>
              </div>
            </div>
          </div>

          {/* Payment Buttons */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginBottom: '1.5rem' }}>
            <Button
              onClick={handlePayment}
              disabled={isProcessing}
              style={{ width: '100%' }}
              className="btn-primary"
            >
              {isProcessing ? (
                <>
                  <i className="fas fa-spinner fa-spin" style={{ marginRight: '0.5rem' }}></i>
                  Processing Payment...
                </>
              ) : (
                <>
                  <i className="fas fa-lock" style={{ marginRight: '0.5rem' }}></i>
                  Pay ${getCartTotal().toFixed(2)}
                </>
              )}
            </Button>

            <Link href="/checkout" style={{ textDecoration: 'none' }}>
              <Button variant="outline" style={{ width: '100%' }}>
                <i className="fas fa-arrow-left" style={{ marginRight: '0.5rem' }}></i>
                Back to Checkout
              </Button>
            </Link>
          </div>

          {/* Security Notice */}
          <div style={{ background: 'rgba(46, 204, 113, 0.1)', border: '1px solid #2ECC71', padding: '1rem', borderRadius: '0.75rem', textAlign: 'center' }}>
            <p style={{ margin: 0, color: '#b0b0b0', fontSize: '0.9rem' }}>
              <i className="fas fa-shield-alt" style={{ marginRight: '0.5rem', color: '#2ECC71' }}></i>
              Your payment information is secure and encrypted with SSL technology
            </p>
          </div>
        </div>

        {/* Additional Info */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginTop: '2rem' }}>
          <div style={{ background: '#1A1F26', padding: '1.5rem', borderRadius: '0.75rem', border: '1px solid rgba(255, 255, 255, 0.1)', textAlign: 'center' }}>
            <div style={{ fontSize: '1.5rem', color: '#FF5733', marginBottom: '0.5rem' }}>
              <i className="fas fa-truck"></i>
            </div>
            <p style={{ margin: 0, fontSize: '0.9rem', color: '#b0b0b0' }}>Fast & Reliable Delivery</p>
          </div>
          <div style={{ background: '#1A1F26', padding: '1.5rem', borderRadius: '0.75rem', border: '1px solid rgba(255, 255, 255, 0.1)', textAlign: 'center' }}>
            <div style={{ fontSize: '1.5rem', color: '#FF5733', marginBottom: '0.5rem' }}>
              <i className="fas fa-undo"></i>
            </div>
            <p style={{ margin: 0, fontSize: '0.9rem', color: '#b0b0b0' }}>30-Day Money Back Guarantee</p>
          </div>
        </div>
      </div>
    </div>
  );
}
