import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

export default function Consultation() {
  return (
    <div style={{ minHeight: '100vh' }}>
      <section style={{ padding: '4rem 0', background: 'rgba(22, 27, 34, 0.5)', textAlign: 'center' }}>
        <div className="container">
          <h1>Health Consultation</h1>
          <p style={{ color: '#b0b0b0', marginTop: '1rem' }}>Choose the consultation type that best fits your needs</p>
        </div>
      </section>

      <section style={{ padding: '4rem 0' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '2rem', maxWidth: '1000px', margin: '0 auto' }}>
            {/* AI Consultation Card */}
            <div
              style={{
                background: '#1A1F26',
                border: '1px solid rgba(255, 255, 255, 0.1)',
                borderRadius: '1rem',
                padding: '2.5rem',
                textAlign: 'center',
                transition: 'all 0.3s ease',
                cursor: 'pointer',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = '#FF5733';
                e.currentTarget.style.boxShadow = '0 10px 30px rgba(255, 87, 51, 0.1)';
                e.currentTarget.style.transform = 'translateY(-5px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                e.currentTarget.style.boxShadow = 'none';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              <div
                style={{
                  width: '80px',
                  height: '80px',
                  background: 'linear-gradient(135deg, #FF5733 0%, #FF6B4A 100%)',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '2rem',
                  color: 'white',
                  margin: '0 auto 1.5rem',
                }}
              >
                <i className="fas fa-robot"></i>
              </div>
              <h3 style={{ margin: '0 0 1rem 0', fontSize: '1.5rem' }}>AI Smart Consultation</h3>
              <p style={{ color: '#b0b0b0', marginBottom: '1.5rem', lineHeight: 1.6 }}>
                Get instant, personalized recommendations powered by advanced AI analysis of your health profile.
              </p>

              <div style={{ textAlign: 'left', margin: '2rem 0', padding: '1.5rem', background: 'rgba(255, 87, 51, 0.05)', borderRadius: '0.75rem' }}>
                {[
                  'Instant Results (2-3 minutes)',
                  '24/7 Availability',
                  'Science-Backed Recommendations',
                  'Contraindication Checking',
                  'Product Filtering',
                ].map((feature, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.75rem', fontSize: '0.95rem' }}>
                    <i className="fas fa-check-circle" style={{ color: '#FF5733' }}></i>
                    <span>{feature}</span>
                  </div>
                ))}
              </div>

              <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#FF5733', margin: '1.5rem 0' }}>Free</div>
              <Link href="/ai-consultation" style={{ textDecoration: 'none' }}>
                <Button style={{ width: '100%' }} className="btn-primary">
                  Start AI Consultation
                </Button>
              </Link>
            </div>

            {/* Expert Consultation Card */}
            <div
              style={{
                background: '#1A1F26',
                border: '1px solid rgba(255, 255, 255, 0.1)',
                borderRadius: '1rem',
                padding: '2.5rem',
                textAlign: 'center',
                transition: 'all 0.3s ease',
                cursor: 'pointer',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = '#F39C12';
                e.currentTarget.style.boxShadow = '0 10px 30px rgba(243, 156, 18, 0.1)';
                e.currentTarget.style.transform = 'translateY(-5px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                e.currentTarget.style.boxShadow = 'none';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              <div
                style={{
                  width: '80px',
                  height: '80px',
                  background: 'linear-gradient(135deg, #F39C12 0%, #F5A623 100%)',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '2rem',
                  color: 'white',
                  margin: '0 auto 1.5rem',
                }}
              >
                <i className="fas fa-user-md"></i>
              </div>
              <h3 style={{ margin: '0 0 1rem 0', fontSize: '1.5rem' }}>Expert Consultation</h3>
              <p style={{ color: '#b0b0b0', marginBottom: '1.5rem', lineHeight: 1.6 }}>
                Book a session with certified nutritionists and fitness professionals for personalized guidance.
              </p>

              <div style={{ textAlign: 'left', margin: '2rem 0', padding: '1.5rem', background: 'rgba(243, 156, 18, 0.05)', borderRadius: '0.75rem' }}>
                {[
                  'One-on-One Session',
                  'Certified Professionals',
                  'Customized Plan',
                  'Follow-up Support',
                  'Ongoing Guidance',
                ].map((feature, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.75rem', fontSize: '0.95rem' }}>
                    <i className="fas fa-check-circle" style={{ color: '#F39C12' }}></i>
                    <span>{feature}</span>
                  </div>
                ))}
              </div>

              <div style={{ fontSize: '1.3rem', fontWeight: 700, color: '#F39C12', margin: '1.5rem 0' }}>$99/session</div>
              <Link href="/booking" style={{ textDecoration: 'none' }}>
                <Button variant="outline" style={{ width: '100%' }}>
                  Book Expert Session
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Additional Info Section */}
      <section style={{ padding: '4rem 0', background: 'rgba(22, 27, 34, 0.5)' }}>
        <div className="container" style={{ maxWidth: '800px' }}>
          <h2 style={{ textAlign: 'center', marginBottom: '2rem' }}>Why Choose BeFit Consultation?</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '2rem' }}>
            {[
              { icon: 'fa-shield-alt', title: 'Medical-Grade Safety', desc: 'All recommendations checked against your health conditions and medications' },
              { icon: 'fa-flask', title: 'Science-Backed', desc: 'Every recommendation is based on peer-reviewed research and clinical studies' },
              { icon: 'fa-check-circle', title: 'Verified Products', desc: 'Only third-party tested and certified supplements recommended' },
            ].map((item, i) => (
              <div key={i} style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '2.5rem', color: '#FF5733', marginBottom: '1rem' }}>
                  <i className={`fas ${item.icon}`}></i>
                </div>
                <h4>{item.title}</h4>
                <p style={{ color: '#b0b0b0', fontSize: '0.9rem' }}>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
