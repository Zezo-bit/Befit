import React, { useState } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { useStore } from '@/contexts/StoreContext';
import { toast } from 'sonner';

const experts = [
  {
    id: 101,
    name: 'Dr. Sarah Ahmed',
    title: 'Clinical Nutritionist & MD',
    description: 'Specializes in medical-grade supplement plans and chronic condition management.',
    rating: 4.9,
    reviews: 120,
    experience: 10,
    image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&w=150&q=80',
  },
  {
    id: 102,
    name: 'Coach Mike Ross',
    title: 'Certified Strength Coach',
    description: 'Expert in hypertrophy, powerlifting, and performance supplementation.',
    rating: 4.8,
    reviews: 85,
    experience: 7,
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=150&q=80',
  },
];

const timeSlots = ['09:00 AM', '10:30 AM', '01:00 PM', '02:30 PM', '04:00 PM', '05:30 PM'];

export default function Booking() {
  const { addToCart } = useStore();
  const [selectedExpert, setSelectedExpert] = useState(experts[0]);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('10:30 AM');

  // Get today's date in YYYY-MM-DD format
  const getTodayDate = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const minDate = getTodayDate();

  const handleAddToCart = () => {
    if (!selectedDate) {
      toast.error('Please select a date for your consultation');
      return;
    }
    addToCart({
      id: `consultation-${selectedExpert.id}-${selectedDate}-${selectedTime}`,
      name: `${selectedExpert.name} - Expert Consultation`,
      price: 99,
      image: selectedExpert.image,
      quantity: 1,
      type: 'consultation',
      date: selectedDate,
      time: selectedTime,
    });
    toast.success('Consultation added to cart!');
  };

  const handleBookAndPay = () => {
    if (!selectedDate) {
      toast.error('Please select a date for your consultation');
      return;
    }
    addToCart({
      id: `consultation-${selectedExpert.id}-${selectedDate}-${selectedTime}`,
      name: `${selectedExpert.name} - Expert Consultation`,
      price: 99,
      image: selectedExpert.image,
      quantity: 1,
      type: 'consultation',
      date: selectedDate,
      time: selectedTime,
    });
    toast.success('Proceeding to payment...');
    setTimeout(() => {
      window.location.href = '/checkout';
    }, 1000);
  };

  const consultationPrice = 99;
  const tax = consultationPrice * 0.05;
  const total = consultationPrice + tax;

  return (
    <div style={{ minHeight: '100vh', padding: '4rem 0' }}>
      <div className="container">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '2rem' }}>
          {/* Expert Selection */}
          <div>
            <h2 style={{ marginBottom: '2rem' }}>
              Choose Your <span style={{ color: '#FF5733' }}>Expert</span>
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              {experts.map((expert) => (
                <div
                  key={expert.id}
                  onClick={() => setSelectedExpert(expert)}
                  style={{
                    background: '#1A1F26',
                    padding: '1.5rem',
                    borderRadius: '1rem',
                    border: selectedExpert.id === expert.id ? '1px solid #FF5733' : '1px solid rgba(255, 255, 255, 0.1)',
                    display: 'flex',
                    gap: '1.5rem',
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    backgroundColor: selectedExpert.id === expert.id ? 'rgba(255, 87, 51, 0.05)' : '#1A1F26',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = '#FF5733';
                    e.currentTarget.style.backgroundColor = 'rgba(255, 87, 51, 0.05)';
                  }}
                  onMouseLeave={(e) => {
                    if (selectedExpert.id !== expert.id) {
                      e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                      e.currentTarget.style.backgroundColor = '#1A1F26';
                    }
                  }}
                >
                  <div
                    style={{
                      width: '80px',
                      height: '80px',
                      borderRadius: '50%',
                      overflow: 'hidden',
                      flexShrink: 0,
                    }}
                  >
                    <img src={expert.image} alt={expert.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  </div>
                  <div>
                    <h3 style={{ marginBottom: '0.25rem' }}>{expert.name}</h3>
                    <p style={{ color: '#FF5733', fontWeight: 600, fontSize: '0.9rem', marginBottom: '0.5rem' }}>{expert.title}</p>
                    <p style={{ fontSize: '0.9rem', color: '#b0b0b0' }}>{expert.description}</p>
                    <div style={{ marginTop: '0.75rem', fontSize: '0.85rem', color: '#b0b0b0' }}>
                      <i className="fas fa-star" style={{ color: '#F1C40F', marginRight: '0.25rem' }}></i>
                      {expert.rating} ({expert.reviews}+ reviews) • {expert.experience} years exp.
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Booking Sidebar */}
          <div>
            <div style={{ background: '#1A1F26', padding: '2rem', borderRadius: '1rem', border: '1px solid rgba(255, 255, 255, 0.1)' }}>
              <h3 style={{ marginBottom: '1.5rem' }}>Select Date & Time</h3>

              <div style={{ marginBottom: '1.5rem' }}>
                <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 600, fontSize: '0.9rem' }}>
                  Date <span style={{ color: '#FF5733' }}>*</span>
                </label>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  min={minDate}
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    background: '#161B22',
                    border: selectedDate ? '1px solid #10B981' : '2px solid rgba(255, 87, 51, 0.5)',
                    borderRadius: '0.5rem',
                    color: '#fff',
                    transition: 'border-color 0.2s',
                  }}
                />
                {!selectedDate && (
                  <p style={{ fontSize: '0.8rem', color: '#FF5733', marginTop: '0.5rem' }}>
                    <i className="fas fa-exclamation-circle" style={{ marginRight: '0.25rem' }}></i>
                    Date is required
                  </p>
                )}
              </div>

              <div style={{ marginBottom: '1.5rem' }}>
                <p style={{ fontSize: '0.9rem', fontWeight: 600, marginBottom: '0.75rem', color: '#b0b0b0' }}>Available Slots</p>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(60px, 1fr))', gap: '0.75rem' }}>
                  {timeSlots.map((time) => (
                    <button
                      key={time}
                      onClick={() => setSelectedTime(time)}
                      style={{
                        padding: '0.75rem',
                        background: selectedTime === time ? '#FF5733' : '#161B22',
                        border: selectedTime === time ? '1px solid #FF5733' : '1px solid rgba(255, 255, 255, 0.1)',
                        borderRadius: '0.5rem',
                        textAlign: 'center',
                        fontSize: '0.9rem',
                        cursor: 'pointer',
                        color: selectedTime === time ? 'white' : '#fff',
                        transition: 'all 0.2s',
                      }}
                      onMouseEnter={(e) => {
                        if (selectedTime !== time) {
                          e.currentTarget.style.borderColor = '#FF5733';
                          e.currentTarget.style.color = '#FF5733';
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (selectedTime !== time) {
                          e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                          e.currentTarget.style.color = '#fff';
                        }
                      }}
                    >
                      {time}
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ marginTop: '2rem', paddingTop: '1.5rem', borderTop: '1px solid rgba(255, 255, 255, 0.1)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                  <span>Expert Consultation (30 min)</span>
                  <span>${consultationPrice.toFixed(2)}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem', color: '#b0b0b0', fontSize: '0.9rem' }}>
                  <span>Tax (5%)</span>
                  <span>${tax.toFixed(2)}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1.5rem', fontSize: '1.1rem', fontWeight: 700 }}>
                  <span>Total</span>
                  <span style={{ color: '#FF5733' }}>${total.toFixed(2)}</span>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginTop: '1.5rem' }}>
                  <Button onClick={handleAddToCart} className="btn-primary" style={{ width: '100%' }}>
                    <i className="fas fa-shopping-cart" style={{ marginRight: '0.5rem' }}></i>
                    Add to Cart
                  </Button>
                  <Button onClick={handleBookAndPay} variant="outline" style={{ width: '100%' }}>
                    <i className="fas fa-calendar-check" style={{ marginRight: '0.5rem' }}></i>
                    Book & Pay Now
                  </Button>
                </div>

                <p style={{ textAlign: 'center', fontSize: '0.85rem', color: '#b0b0b0', marginTop: '1rem' }}>
                  <i className="fas fa-lock" style={{ marginRight: '0.5rem' }}></i>
                  Secure Payment Guaranteed
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
