import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ProductCard } from '@/components/ProductCard';
import { useStore } from '@/contexts/StoreContext';

export default function Home() {
  const { products } = useStore();
  const featuredProducts = products.slice(0, 4);

  return (
    <div style={{ minHeight: '100vh' }}>
      {/* Hero Section */}
      <section
        style={{
          padding: '4rem 0',
          background: 'linear-gradient(135deg, rgba(11, 14, 17, 0.8) 0%, rgba(22, 27, 34, 0.6) 100%)',
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'radial-gradient(circle at 20% 50%, rgba(255, 87, 51, 0.1) 0%, transparent 50%)',
            pointerEvents: 'none',
          }}
        ></div>

        <div className="container" style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '4rem', alignItems: 'center' }}>
            {/* Hero Content */}
            <div>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.5rem', background: 'rgba(255, 87, 51, 0.1)', padding: '0.75rem 1.5rem', borderRadius: '1rem', width: 'fit-content' }}>
                <i className="fas fa-rocket" style={{ color: '#FF5733' }}></i>
                <span style={{ color: '#FF5733', fontWeight: 600 }}>Health-First E-Commerce</span>
              </div>

              <h1 style={{ marginBottom: '1.5rem', fontSize: 'clamp(1.5rem, 5vw, 3.5rem)', fontWeight: 800 }}>
                Fitness Science, Not Bro-Science. <span style={{ color: '#FF5733' }}>Shop Safely.</span>
              </h1>

              <p style={{ fontSize: '1.1rem', color: '#b0b0b0', marginBottom: '2rem', lineHeight: 1.8 }}>
                The first e-commerce store that analyzes your health profile to recommend medically safe supplements and equipment.
              </p>

              <div style={{ display: 'flex', gap: '1.5rem', marginBottom: '2rem', flexWrap: 'wrap' }}>
                <Link href="/consultation" style={{ textDecoration: 'none' }}>
                  <Button style={{ padding: '1.5rem 3rem', fontSize: '1.05rem' }} className="btn-primary">
                    <i className="fas fa-arrow-right" style={{ marginRight: '0.5rem' }}></i> Start Smart Consultation
                  </Button>
                </Link>
                <Link href="/shop" style={{ textDecoration: 'none' }}>
                  <Button variant="outline" style={{ padding: '1.5rem 3rem', fontSize: '1.05rem' }}>
                    Browse Catalog
                  </Button>
                </Link>
              </div>

              <div style={{ display: 'flex', gap: '3rem', fontSize: '0.95rem', flexWrap: 'wrap' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <i className="fas fa-check-circle" style={{ color: '#FF5733', fontSize: '1.2rem' }}></i>
                  <span>Medical-grade verification</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <i className="fas fa-check-circle" style={{ color: '#FF5733', fontSize: '1.2rem' }}></i>
                  <span>10,000+ Safe Products</span>
                </div>
              </div>
            </div>

            {/* Hero Image */}
            <div style={{ position: 'relative', borderRadius: '1.5rem', overflow: 'hidden', boxShadow: '0 12px 32px rgba(0, 0, 0, 0.25)' }}>
              <img
                src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=500&q=80"
                alt="Hero"
                style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
              />
              <div style={{ position: 'absolute', bottom: '1.5rem', right: '1.5rem', background: 'rgba(11, 14, 17, 0.9)', backdropFilter: 'blur(10px)', padding: '1rem 1.5rem', borderRadius: '1rem', border: '1px solid rgba(255, 255, 255, 0.1)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <div style={{ color: '#2ECC71', fontSize: '1.2rem' }}>
                  <i className="fas fa-check-circle"></i>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                  <div style={{ fontSize: '0.75rem', color: '#808080' }}>Safety Check</div>
                  <div style={{ fontSize: '0.95rem', fontWeight: 600, color: '#ffffff' }}>Passed</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section style={{ padding: '4rem 0', background: '#0B0E11' }}>
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '4rem' }}>
            <h2 style={{ marginBottom: '1rem' }}>Why Choose BeFit?</h2>
            <p style={{ fontSize: '1.05rem', maxWidth: '600px', margin: '0 auto', color: '#b0b0b0' }}>
              We combine science, safety, and personalization to revolutionize fitness e-commerce.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '3rem' }}>
            {[
              { icon: 'fa-shield-alt', title: 'Medical-Grade Safety', desc: 'All recommendations checked against your health conditions and medications' },
              { icon: 'fa-flask', title: 'Science-Backed', desc: 'Every recommendation is based on peer-reviewed research and clinical studies' },
              { icon: 'fa-check-circle', title: 'Verified Products', desc: 'Only third-party tested and certified supplements recommended' },
            ].map((feature, i) => (
              <div
                key={i}
                style={{
                  background: '#1A1F26',
                  padding: '3rem 2rem',
                  borderRadius: '1.25rem',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  textAlign: 'center',
                  transition: 'all 250ms ease-in-out',
                  cursor: 'pointer',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-8px)';
                  e.currentTarget.style.borderColor = '#FF5733';
                  e.currentTarget.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.2)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                  e.currentTarget.style.boxShadow = 'none';
                }}
              >
                <div
                  style={{
                    width: '60px',
                    height: '60px',
                    background: 'linear-gradient(135deg, #FF5733 0%, #FF6B4A 100%)',
                    borderRadius: '1rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '1.8rem',
                    margin: '0 auto 1.5rem',
                    color: 'white',
                  }}
                >
                  <i className={`fas ${feature.icon}`}></i>
                </div>
                <h3 style={{ marginBottom: '1rem' }}>{feature.title}</h3>
                <p style={{ fontSize: '0.95rem', lineHeight: 1.6, color: '#b0b0b0' }}>{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Myth vs Fact Section */}
      <section style={{ padding: '4rem 0', background: 'linear-gradient(135deg, rgba(11, 14, 17, 0.8) 0%, rgba(22, 27, 34, 0.6) 100%)' }}>
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '4rem' }}>
            <h2 style={{ marginBottom: '1rem' }}>Myth vs Fact</h2>
            <p style={{ fontSize: '1.05rem', maxWidth: '600px', margin: '0 auto', color: '#b0b0b0' }}>
              Separating fitness facts from fiction with science-backed information.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '3rem', marginBottom: '4rem' }}>
            <div style={{ background: 'rgba(231, 76, 60, 0.1)', padding: '3rem 2rem', borderRadius: '1.25rem', borderLeft: '4px solid #E74C3C' }}>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.85rem', fontWeight: 700, marginBottom: '1rem', padding: '0.5rem 1rem', borderRadius: '0.75rem', background: 'rgba(231, 76, 60, 0.2)', color: '#FF6B6B', width: 'fit-content' }}>
                <i className="fas fa-times-circle"></i> Myth
              </div>
              <h3 style={{ marginBottom: '1rem', fontSize: '1.3rem' }}>More protein = More muscle</h3>
              <p style={{ color: '#b0b0b0', marginBottom: '1.5rem' }}>
                While protein is essential, excess protein without proper training and recovery won't build muscle. Quality matters more than quantity.
              </p>
              <div style={{ marginTop: '1.5rem', padding: '1rem 1.5rem', borderRadius: '0.75rem', background: 'rgba(231, 76, 60, 0.15)', color: '#FF8787', fontSize: '0.9rem' }}>
                <i className="fas fa-exclamation-circle" style={{ marginRight: '0.5rem' }}></i>
                Excess protein is stored as fat without proper training
              </div>
            </div>

            <div style={{ background: 'rgba(46, 204, 113, 0.1)', padding: '3rem 2rem', borderRadius: '1.25rem', borderLeft: '4px solid #2ECC71' }}>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.85rem', fontWeight: 700, marginBottom: '1rem', padding: '0.5rem 1rem', borderRadius: '0.75rem', background: 'rgba(46, 204, 113, 0.2)', color: '#51CF66', width: 'fit-content' }}>
                <i className="fas fa-check-circle"></i> Fact
              </div>
              <h3 style={{ marginBottom: '1rem', fontSize: '1.3rem' }}>Protein + Training = Muscle</h3>
              <p style={{ color: '#b0b0b0', marginBottom: '1.5rem' }}>
                Adequate protein (0.7-1g per lb) combined with resistance training and recovery creates the optimal environment for muscle growth.
              </p>
              <div style={{ marginTop: '1.5rem', padding: '1rem 1.5rem', borderRadius: '0.75rem', background: 'rgba(46, 204, 113, 0.15)', color: '#69DB7C', fontSize: '0.9rem' }}>
                <i className="fas fa-check" style={{ marginRight: '0.5rem' }}></i>
                Science-backed approach for sustainable gains
              </div>
            </div>
          </div>

          <Link href="/myth-vs-fact" style={{ textDecoration: 'none', display: 'flex', justifyContent: 'center' }}>
            <Button variant="outline">View More Myths & Facts</Button>
          </Link>
        </div>
      </section>

      {/* Products Section */}
      <section style={{ padding: '4rem 0', background: '#0B0E11' }}>
        <div className="container">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '3rem' }}>
            <h2 style={{ margin: 0 }}>Featured Products</h2>
            <Link href="/shop" style={{ textDecoration: 'none' }}>
              <Button variant="outline">View All Products</Button>
            </Link>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '3rem' }}>
            {featuredProducts.map((product) => (
              <ProductCard
                key={product.id}
                id={product.id}
                name={product.name}
                price={product.price}
                image={product.image}
                description={product.description}
                rating={product.rating}
                reviews={product.reviews}
                safetyScore={product.safetyScore}
                recommended={product.recommended}
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section style={{ padding: '4rem 0', background: 'linear-gradient(135deg, rgba(255, 87, 51, 0.1) 0%, rgba(255, 107, 74, 0.05) 100%)', textAlign: 'center' }}>
        <div className="container">
          <h2 style={{ marginBottom: '1rem' }}>Ready to Shop Safely?</h2>
          <p style={{ fontSize: '1.1rem', color: '#b0b0b0', marginBottom: '2rem', maxWidth: '600px', margin: '0 auto 2rem' }}>
            Start your health journey with personalized recommendations from our AI and expert consultants.
          </p>
          <Link href="/consultation" style={{ textDecoration: 'none' }}>
            <Button style={{ padding: '1.5rem 3rem', fontSize: '1.05rem' }} className="btn-primary">
              Get Started Now
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
