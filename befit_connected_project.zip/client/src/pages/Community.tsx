import React, { useState } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { useStore } from '@/contexts/StoreContext';
import { Heart, MessageCircle, Share2, Search, TrendingUp, Users, Flame, Award, Zap } from 'lucide-react';
import { toast } from 'sonner';

interface Comment {
  id: number;
  author: string;
  content: string;
  timestamp: string;
}

interface CommunityPost {
  id: number;
  author: string;
  avatar: string;
  title: string;
  content: string;
  likes: number;
  comments: number;
  shares: number;
  timestamp: string;
  category: string;
  image?: string;
  liked?: boolean;
  verified?: boolean;
  postComments?: Comment[];
}

const communityPosts: CommunityPost[] = [
  {
    id: 1,
    author: 'Alex Johnson',
    avatar: '👨‍💪',
    title: '90-Day Transformation: From 0 to Hero',
    content: 'Started my fitness journey 3 months ago with BeFit AI consultation. Gained 12 lbs of pure muscle, lost 8 lbs of fat. The personalized supplement stack was a game-changer. Here\'s my complete transformation breakdown...',
    likes: 2340,
    comments: 156,
    shares: 89,
    timestamp: '2 days ago',
    category: 'Transformation',
    verified: true,
    liked: false,
  },
  {
    id: 2,
    author: 'Sarah Williams',
    avatar: '👩‍🦰',
    title: 'The Ultimate Beginner\'s Supplement Guide',
    content: 'After consulting with BeFit AI, I started with just 3 supplements: Whey Protein, Creatine, and Omega-3. The results have been incredible! Here\'s exactly what I take and why...',
    likes: 1890,
    comments: 234,
    shares: 145,
    timestamp: '5 days ago',
    category: 'Guide',
    verified: true,
    liked: false,
  },
  {
    id: 3,
    author: 'Mike Chen',
    avatar: '👨‍🏫',
    title: 'Nutrition Timing: The Secret Nobody Talks About',
    content: 'Been training for 15 years and I finally cracked the code on nutrition timing. Combined with BeFit\'s recommendations, my gains have accelerated 3x. Let me share the science behind it...',
    likes: 3120,
    comments: 412,
    shares: 267,
    timestamp: '1 week ago',
    category: 'Nutrition',
    verified: true,
    liked: false,
  },
  {
    id: 4,
    author: 'Emma Davis',
    avatar: '👩‍⚕️',
    title: 'Recovery Protocols That Actually Work (Backed by Science)',
    content: 'As a sports medicine specialist, I\'ve tested every recovery method. Here\'s what actually works combined with smart supplementation from BeFit...',
    likes: 1560,
    comments: 198,
    shares: 92,
    timestamp: '10 days ago',
    category: 'Recovery',
    verified: true,
    liked: false,
  },
];

const categories = ['All', 'Transformation', 'Guide', 'Nutrition', 'Recovery', 'Workouts', 'Tips'];

export default function Community() {
  const { user } = useStore();
  const [posts, setPosts] = useState<CommunityPost[]>(communityPosts.map(p => ({ ...p, postComments: [] })));
  const [newPost, setNewPost] = useState('');
  const [newPostTitle, setNewPostTitle] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('trending');
  const [showPostForm, setShowPostForm] = useState(false);
  const [activeCommentId, setActiveCommentId] = useState<number | null>(null);
  const [commentText, setCommentText] = useState('');

  const handlePostSubmit = () => {
    if (!user) {
      toast.error('Please log in to post');
      return;
    }

    if (!newPost.trim() || !newPostTitle.trim()) {
      toast.error('Please fill in all fields');
      return;
    }

    const post: CommunityPost = {
      id: posts.length + 1,
      author: user.name,
      avatar: '👤',
      title: newPostTitle,
      content: newPost,
      likes: 0,
      comments: 0,
      shares: 0,
      timestamp: 'just now',
      category: selectedCategory !== 'All' ? selectedCategory : 'General',
      liked: false,
      verified: false,
    };
    setPosts([post, ...posts]);
    setNewPost('');
    setNewPostTitle('');
    setShowPostForm(false);
    toast.success('Post published successfully!');
  };

  const handleLike = (postId: number) => {
    setPosts(posts.map(post =>
      post.id === postId
        ? { ...post, likes: post.liked ? post.likes - 1 : post.likes + 1, liked: !post.liked }
        : post
    ));
  };

  const handleShare = (post: CommunityPost) => {
    const shareUrl = window.location.href;
    if (navigator.share) {
      navigator.share({
        title: post.title,
        text: post.content,
        url: shareUrl,
      }).then(() => {
        setPosts(posts.map(p => p.id === post.id ? { ...p, shares: p.shares + 1 } : p));
        toast.success('Shared successfully!');
      }).catch(console.error);
    } else {
      navigator.clipboard.writeText(`${post.title}\n${shareUrl}`).then(() => {
        setPosts(posts.map(p => p.id === post.id ? { ...p, shares: p.shares + 1 } : p));
        toast.success('Link copied to clipboard!');
      });
    }
  };

  const handleAddComment = (postId: number) => {
    if (!user) {
      toast.error('Please log in to comment');
      return;
    }
    if (!commentText.trim()) return;

    setPosts(posts.map(post => {
      if (post.id === postId) {
        const newComment: Comment = {
          id: Date.now(),
          author: user.name,
          content: commentText,
          timestamp: 'just now'
        };
        return {
          ...post,
          comments: post.comments + 1,
          postComments: [...(post.postComments || []), newComment]
        };
      }
      return post;
    }));
    setCommentText('');
    toast.success('Comment added!');
  };

  const filteredPosts = posts
    .filter(post => selectedCategory === 'All' || post.category === selectedCategory)
    .filter(post =>
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.content.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => {
      if (sortBy === 'trending') return (b.likes + b.comments * 2) - (a.likes + a.comments * 2);
      if (sortBy === 'popular') return b.likes - a.likes;
      return 0;
    });

  return (
    <div style={{ minHeight: '100vh', background: '#0B0E11' }}>
      {/* Hero Section */}
      <section
        style={{
          padding: '5rem 0',
          background: 'linear-gradient(135deg, rgba(11, 14, 17, 0.8) 0%, rgba(22, 27, 34, 0.6) 100%)',
          position: 'relative',
          overflow: 'hidden',
          borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
        }}
      >
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'radial-gradient(circle at 20% 50%, rgba(255, 87, 51, 0.15) 0%, transparent 50%)',
            pointerEvents: 'none',
          }}
        ></div>

        <div className="container" style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1.5rem', background: 'rgba(255, 87, 51, 0.1)', padding: '0.75rem 1.5rem', borderRadius: '1rem', border: '1px solid rgba(255, 87, 51, 0.2)' }}>
              <Users size={20} style={{ color: '#FF5733' }} />
              <span style={{ color: '#FF5733', fontWeight: 600, fontSize: '0.95rem' }}>Fitness Community</span>
            </div>
            <h1 style={{ marginBottom: '1rem', fontSize: 'clamp(1.5rem, 5vw, 3rem)', fontWeight: 800, lineHeight: 1.2 }}>
              Connect, Share & <span style={{ color: '#FF5733' }}>Grow Together</span>
            </h1>
            <p style={{ color: '#b0b0b0', maxWidth: '700px', margin: '0 auto', fontSize: '1.1rem', lineHeight: 1.7 }}>
              Join a thriving community of fitness enthusiasts. Share your journey, get inspired, and achieve your goals together.
            </p>
          </div>

          {/* Community Stats */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '2rem' }}>
            <div style={{ textAlign: 'center', padding: '2rem', background: 'rgba(255, 87, 51, 0.08)', borderRadius: '1rem', border: '1px solid rgba(255, 87, 51, 0.2)', backdropFilter: 'blur(10px)' }}>
              <Users size={32} style={{ color: '#FF5733', margin: '0 auto 1rem' }} />
              <div style={{ fontSize: '2.5rem', fontWeight: 800, color: '#FF5733', marginBottom: '0.5rem' }}>12.5K+</div>
              <div style={{ color: '#b0b0b0', fontSize: '0.95rem' }}>Active Members</div>
            </div>
            <div style={{ textAlign: 'center', padding: '2rem', background: 'rgba(255, 87, 51, 0.08)', borderRadius: '1rem', border: '1px solid rgba(255, 87, 51, 0.2)', backdropFilter: 'blur(10px)' }}>
              <Flame size={32} style={{ color: '#FF5733', margin: '0 auto 1rem' }} />
              <div style={{ fontSize: '2.5rem', fontWeight: 800, color: '#FF5733', marginBottom: '0.5rem' }}>45.2K+</div>
              <div style={{ color: '#b0b0b0', fontSize: '0.95rem' }}>Total Posts</div>
            </div>
            <div style={{ textAlign: 'center', padding: '2rem', background: 'rgba(255, 87, 51, 0.08)', borderRadius: '1rem', border: '1px solid rgba(255, 87, 51, 0.2)', backdropFilter: 'blur(10px)' }}>
              <Award size={32} style={{ color: '#FF5733', margin: '0 auto 1rem' }} />
              <div style={{ fontSize: '2.5rem', fontWeight: 800, color: '#FF5733', marginBottom: '0.5rem' }}>98%</div>
              <div style={{ color: '#b0b0b0', fontSize: '0.95rem' }}>Positive Feedback</div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section style={{ padding: '4rem 0' }}>
        <div className="container" style={{ maxWidth: '1000px' }}>
          {/* Create Post Section */}
          {user ? (
            <div
              style={{
                background: '#1A1F26',
                padding: '2rem',
                borderRadius: '1.5rem',
                border: '1px solid rgba(255, 255, 255, 0.1)',
                marginBottom: '3rem',
              }}
            >
              {!showPostForm ? (
                <div
                  onClick={() => setShowPostForm(true)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '1rem',
                    cursor: 'pointer',
                    padding: '1rem',
                    background: '#161B22',
                    borderRadius: '1rem',
                    transition: 'all 0.3s ease',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = 'rgba(255, 87, 51, 0.3)';
                    e.currentTarget.style.background = '#1F2530';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                    e.currentTarget.style.background = '#161B22';
                  }}
                >
                  <div style={{ fontSize: '2rem' }}>👤</div>
                  <input
                    type="text"
                    placeholder="Share your fitness story..."
                    style={{
                      flex: 1,
                      background: 'transparent',
                      border: 'none',
                      color: '#b0b0b0',
                      outline: 'none',
                      fontFamily: 'inherit',
                      fontSize: '0.95rem',
                      cursor: 'pointer',
                    }}
                    onClick={() => setShowPostForm(true)}
                    readOnly
                  />
                  <Zap size={20} style={{ color: '#FF5733' }} />
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                  <input
                    type="text"
                    placeholder="Post title..."
                    value={newPostTitle}
                    onChange={(e) => setNewPostTitle(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '0.75rem 1rem',
                      background: '#161B22',
                      border: '1px solid rgba(255, 255, 255, 0.1)',
                      borderRadius: '0.75rem',
                      color: '#fff',
                      fontFamily: 'inherit',
                      fontSize: '1rem',
                      fontWeight: 600,
                    }}
                  />
                  <textarea
                    value={newPost}
                    onChange={(e) => setNewPost(e.target.value)}
                    placeholder="Share your fitness story, tips, or achievements..."
                    style={{
                      width: '100%',
                      padding: '1rem',
                      background: '#161B22',
                      border: '1px solid rgba(255, 255, 255, 0.1)',
                      borderRadius: '0.75rem',
                      color: '#fff',
                      fontFamily: 'inherit',
                      minHeight: '140px',
                      resize: 'vertical',
                      fontSize: '0.95rem',
                    }}
                  />
                  <div style={{ display: 'flex', gap: '1rem', justifyContent: 'space-between', alignItems: 'center' }}>
                    <select
                      value={selectedCategory === 'All' ? 'General' : selectedCategory}
                      onChange={(e) => setSelectedCategory(e.target.value)}
                      style={{
                        padding: '0.75rem 1rem',
                        background: '#161B22',
                        border: '1px solid rgba(255, 255, 255, 0.1)',
                        borderRadius: '0.75rem',
                        color: '#fff',
                        fontFamily: 'inherit',
                        fontSize: '0.9rem',
                        cursor: 'pointer',
                      }}
                    >
                      {categories.map(cat => (
                        <option key={cat} value={cat === 'All' ? 'General' : cat}>
                          {cat}
                        </option>
                      ))}
                    </select>
                    <div style={{ display: 'flex', gap: '1rem' }}>
                      <Button
                        variant="outline"
                        onClick={() => {
                          setShowPostForm(false);
                          setNewPost('');
                          setNewPostTitle('');
                        }}
                      >
                        Cancel
                      </Button>
                      <Button onClick={handlePostSubmit} className="btn-primary">
                        Publish Post
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: '3rem', background: '#1A1F26', borderRadius: '1.5rem', border: '1px solid rgba(255, 255, 255, 0.1)', marginBottom: '3rem' }}>
              <p style={{ color: '#b0b0b0', marginBottom: '1.5rem', fontSize: '1rem' }}>Sign in to share your fitness journey with the community</p>
              <Link href="/login" style={{ textDecoration: 'none' }}>
                <Button className="btn-primary">Sign In to Post</Button>
              </Link>
            </div>
          )}

          {/* Search and Filter */}
          <div style={{ display: 'flex', gap: '1rem', marginBottom: '2rem', flexWrap: 'wrap', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', background: '#1A1F26', padding: '0.75rem 1.25rem', borderRadius: '0.75rem', border: '1px solid rgba(255, 255, 255, 0.1)', flex: 1, minWidth: '250px' }}>
              <Search size={18} style={{ color: '#b0b0b0' }} />
              <input
                type="text"
                placeholder="Search posts..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{
                  background: 'transparent',
                  border: 'none',
                  color: '#fff',
                  outline: 'none',
                  width: '100%',
                  fontFamily: 'inherit',
                  fontSize: '0.95rem',
                }}
              />
            </div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              style={{
                padding: '0.75rem 1.25rem',
                background: '#1A1F26',
                border: '1px solid rgba(255, 255, 255, 0.1)',
                borderRadius: '0.75rem',
                color: '#fff',
                fontFamily: 'inherit',
                cursor: 'pointer',
                fontSize: '0.95rem',
              }}
            >
              <option value="trending">Trending</option>
              <option value="popular">Most Liked</option>
              <option value="recent">Recent</option>
            </select>
          </div>

          {/* Category Filter */}
          <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '3rem', flexWrap: 'wrap' }}>
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                style={{
                  padding: '0.65rem 1.25rem',
                  background: selectedCategory === category ? '#FF5733' : '#1A1F26',
                  border: selectedCategory === category ? 'none' : '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '0.75rem',
                  color: selectedCategory === category ? '#fff' : '#b0b0b0',
                  cursor: 'pointer',
                  fontWeight: selectedCategory === category ? 600 : 400,
                  transition: 'all 0.3s ease',
                  fontSize: '0.9rem',
                }}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Posts */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            {filteredPosts.length > 0 ? (
              filteredPosts.map((post) => (
                <div
                  key={post.id}
                  style={{
                    background: '#1A1F26',
                    padding: '2rem',
                    borderRadius: '1.5rem',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    transition: 'all 0.3s ease',
                    cursor: 'pointer',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = 'rgba(255, 87, 51, 0.4)';
                    e.currentTarget.style.background = '#1F2530';
                    e.currentTarget.style.boxShadow = '0 8px 24px rgba(255, 87, 51, 0.12)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                    e.currentTarget.style.background = '#1A1F26';
                    e.currentTarget.style.boxShadow = 'none';
                  }}
                >
                  {/* Header */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem' }}>
                    <div style={{ fontSize: '2.5rem' }}>{post.avatar}</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.5rem' }}>
                        <div style={{ fontWeight: 600, fontSize: '1rem' }}>{post.author}</div>
                        {post.verified && (
                          <div style={{ background: 'rgba(46, 204, 113, 0.2)', color: '#2ECC71', padding: '0.25rem 0.75rem', borderRadius: '0.5rem', fontSize: '0.75rem', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                            ✓ Verified
                          </div>
                        )}
                        <span style={{ background: 'rgba(255, 87, 51, 0.15)', color: '#FF5733', padding: '0.35rem 0.85rem', borderRadius: '0.5rem', fontSize: '0.8rem', fontWeight: 600 }}>
                          {post.category}
                        </span>
                      </div>
                      <div style={{ color: '#808080', fontSize: '0.85rem' }}>{post.timestamp}</div>
                    </div>
                  </div>

                  {/* Content */}
                  <h3 style={{ marginBottom: '1rem', fontSize: '1.25rem', fontWeight: 700, lineHeight: 1.3 }}>{post.title}</h3>
                  <p style={{ color: '#b0b0b0', lineHeight: 1.7, marginBottom: '1.5rem', fontSize: '0.95rem' }}>
                    {post.content}
                  </p>

                  {/* Actions */}
                  <div style={{ display: 'flex', gap: '2rem', color: '#b0b0b0', fontSize: '0.9rem', borderTop: '1px solid rgba(255, 255, 255, 0.05)', paddingTop: '1.5rem' }}>
                    <button
                      onClick={() => handleLike(post.id)}
                      style={{
                        background: 'none',
                        border: 'none',
                        color: post.liked ? '#FF5733' : '#b0b0b0',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.75rem',
                        transition: 'all 0.3s ease',
                        fontWeight: post.liked ? 600 : 400,
                        fontSize: '0.95rem',
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.color = '#FF5733';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.color = post.liked ? '#FF5733' : '#b0b0b0';
                      }}
                    >
                      <Heart size={20} fill={post.liked ? '#FF5733' : 'none'} />
                      {post.likes}
                    </button>
                    <button
                      onClick={() => setActiveCommentId(activeCommentId === post.id ? null : post.id)}
                      style={{
                        background: 'none',
                        border: 'none',
                        color: activeCommentId === post.id ? '#FF5733' : '#b0b0b0',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.75rem',
                        transition: 'all 0.3s ease',
                        fontSize: '0.95rem',
                      }}
                      onMouseEnter={(e) => {
                        if (activeCommentId !== post.id) e.currentTarget.style.color = '#FF5733';
                      }}
                      onMouseLeave={(e) => {
                        if (activeCommentId !== post.id) e.currentTarget.style.color = '#b0b0b0';
                      }}
                    >
                      <MessageCircle size={20} />
                      {post.comments}
                    </button>
                    <button
                      onClick={() => handleShare(post)}
                      style={{
                        background: 'none',
                        border: 'none',
                        color: '#b0b0b0',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.75rem',
                        transition: 'all 0.3s ease',
                        fontSize: '0.95rem',
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.color = '#FF5733';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.color = '#b0b0b0';
                      }}
                    >
                      <Share2 size={20} />
                      {post.shares}
                    </button>
                  </div>

                  {/* Comments Section */}
                  {activeCommentId === post.id && (
                    <div style={{ marginTop: '2rem', paddingTop: '2rem', borderTop: '1px solid rgba(255, 255, 255, 0.1)' }}>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                        {post.postComments && post.postComments.length > 0 ? (
                          post.postComments.map(comment => (
                            <div key={comment.id} style={{ display: 'flex', gap: '1rem' }}>
                              <div style={{ fontSize: '1.5rem' }}>👤</div>
                              <div style={{ flex: 1, background: '#161B22', padding: '1rem', borderRadius: '1rem' }}>
                                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                                  <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>{comment.author}</span>
                                  <span style={{ color: '#808080', fontSize: '0.8rem' }}>{comment.timestamp}</span>
                                </div>
                                <p style={{ fontSize: '0.9rem', color: '#b0b0b0', lineHeight: 1.5 }}>{comment.content}</p>
                              </div>
                            </div>
                          ))
                        ) : (
                          <p style={{ color: '#808080', fontSize: '0.9rem', textAlign: 'center' }}>No comments yet. Be the first to comment!</p>
                        )}

                        {/* Add Comment Input */}
                        <div style={{ display: 'flex', gap: '1rem', marginTop: '0.5rem' }}>
                          <div style={{ fontSize: '1.5rem' }}>👤</div>
                          <div style={{ flex: 1, position: 'relative' }}>
                            <input
                              type="text"
                              value={commentText}
                              onChange={(e) => setCommentText(e.target.value)}
                              onKeyPress={(e) => e.key === 'Enter' && handleAddComment(post.id)}
                              placeholder="Write a comment..."
                              style={{
                                width: '100%',
                                padding: '0.75rem 1rem',
                                background: '#161B22',
                                border: '1px solid rgba(255, 255, 255, 0.1)',
                                borderRadius: '0.75rem',
                                color: '#fff',
                                fontFamily: 'inherit',
                                fontSize: '0.9rem',
                              }}
                            />
                            <button
                              onClick={() => handleAddComment(post.id)}
                              style={{
                                position: 'absolute',
                                right: '0.5rem',
                                top: '50%',
                                transform: 'translateY(-50%)',
                                background: 'none',
                                border: 'none',
                                color: '#FF5733',
                                cursor: 'pointer',
                                fontWeight: 600,
                                fontSize: '0.85rem',
                              }}
                            >
                              Post
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))
            ) : (
              <div style={{ textAlign: 'center', padding: '4rem 2rem', color: '#b0b0b0' }}>
                <p style={{ fontSize: '1.1rem', marginBottom: '1rem' }}>No posts found</p>
                <p style={{ fontSize: '0.95rem', color: '#808080' }}>Try adjusting your filters or search terms</p>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
