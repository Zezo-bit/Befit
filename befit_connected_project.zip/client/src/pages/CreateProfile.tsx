import React from 'react';
import { Link } from 'wouter';

export default function CreateProfile() {
  return (
    <>
      <Link href="/ai-consultation" />
    </>
  );
}
