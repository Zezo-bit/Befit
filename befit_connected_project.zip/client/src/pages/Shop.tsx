import React, { useState, useMemo } from 'react';
import { Link } from 'wouter';
import { ProductCard } from '@/components/ProductCard';
import { useStore } from '@/contexts/StoreContext';

export default function Shop() {
  const { products } = useStore();
  const [selectedCategories, setSelectedCategories] = useState<string[]>(['supplements']);
  const [maxPrice, setMaxPrice] = useState(500);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      const matchesCategory =
        selectedCategories.length === 0 ||
        selectedCategories.some(
          (cat) =>
            product.category?.toLowerCase().includes(cat) ||
            product.name.toLowerCase().includes(cat)
        );

      const matchesPrice = product.price <= maxPrice;

      const matchesSearch =
        searchTerm === '' ||
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.description?.toLowerCase().includes(searchTerm.toLowerCase());

      return matchesCategory && matchesPrice && matchesSearch;
    });
  }, [products, selectedCategories, maxPrice, searchTerm]);

  const handleCategoryChange = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category)
        ? prev.filter((c) => c !== category)
        : [...prev, category]
    );
  };

  return (
    <div style={{ minHeight: '100vh' }}>
      <section style={{ padding: '4rem 0', background: 'rgba(22, 27, 34, 0.5)', textAlign: 'center' }}>
        <div className="container">
          <h1>Shop</h1>
          <p style={{ color: '#b0b0b0', marginTop: '1rem' }}>Browse our collection of science-backed supplements and equipment.</p>
        </div>
      </section>

      <section style={{ padding: '4rem 0' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '3rem' }}>
            {/* Sidebar Filters */}
            <aside style={{ background: '#1A1F26', padding: '1.5rem', borderRadius: '1rem', height: 'fit-content', position: 'sticky', top: '100px' }}>
              <h3 style={{ marginBottom: '1rem' }}>Filters</h3>

              <div style={{ marginBottom: '1.5rem' }}>
                <h4 style={{ marginBottom: '0.5rem' }}>Search</h4>
                <input
                  type="text"
                  placeholder="Search products..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    background: '#161B22',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    borderRadius: '0.75rem',
                    color: '#ffffff',
                    fontSize: '0.9rem',
                  }}
                />
              </div>

              <div style={{ marginBottom: '1.5rem' }}>
                <h4 style={{ marginBottom: '0.5rem' }}>Category</h4>
                {['supplements', 'equipment', 'bundles'].map((cat) => (
                  <label
                    key={cat}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.5rem',
                      marginBottom: '0.5rem',
                      cursor: 'pointer',
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={selectedCategories.includes(cat)}
                      onChange={() => handleCategoryChange(cat)}
                    />
                    <span style={{ textTransform: 'capitalize' }}>{cat}</span>
                  </label>
                ))}
              </div>

              <div>
                <h4 style={{ marginBottom: '0.5rem' }}>Price Range</h4>
                <input
                  type="range"
                  min="0"
                  max="500"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(parseInt(e.target.value))}
                  style={{ width: '100%', marginBottom: '0.5rem' }}
                />
                <span style={{ marginLeft: '10px' }}>${maxPrice}</span>
              </div>
            </aside>

            {/* Products Grid */}
            <div style={{ gridColumn: 'span 1' }}>
              {filteredProducts.length > 0 ? (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '2rem' }}>
                  {filteredProducts.map((product) => (
                    <ProductCard
                      key={product.id}
                      id={product.id}
                      name={product.name}
                      price={product.price}
                      image={product.image}
                      description={product.description}
                      rating={product.rating}
                      reviews={product.reviews}
                      safetyScore={product.safetyScore}
                      recommended={product.recommended}
                    />
                  ))}
                </div>
              ) : (
                <div style={{ textAlign: 'center', padding: '4rem 2rem', background: '#1A1F26', borderRadius: '1rem', border: '1px solid rgba(255, 255, 255, 0.1)' }}>
                  <div style={{ fontSize: '3rem', color: '#FF5733', marginBottom: '1rem' }}>
                    <i className="fas fa-search"></i>
                  </div>
                  <h3 style={{ marginBottom: '0.5rem' }}>No products found</h3>
                  <p style={{ color: '#808080' }}>Try adjusting your filters or search term</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
