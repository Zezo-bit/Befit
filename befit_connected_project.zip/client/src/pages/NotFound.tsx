import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

export default function NotFound() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', textAlign: 'center', padding: '2rem' }}>
      <div
        style={{
          fontSize: '8rem',
          fontWeight: 800,
          background: 'linear-gradient(135deg, #FF5733 0%, #FF6B4A 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          backgroundClip: 'text',
          lineHeight: 1,
          marginBottom: '1rem',
        }}
      >
        404
      </div>

      <div style={{ fontSize: '6rem', marginBottom: '2rem', animation: 'float 3s ease-in-out infinite' }}>
        <i className="fas fa-search"></i>
      </div>

      <h1 style={{ fontSize: '2.5rem', fontWeight: 700, marginBottom: '1rem' }}>Page Not Found</h1>

      <p style={{ fontSize: '1.1rem', color: '#b0b0b0', maxWidth: '500px', marginBottom: '2rem', lineHeight: 1.8 }}>
        The page you're looking for doesn't exist or has been moved. Let's get you back on track with your fitness journey.
      </p>

      <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
        <Link href="/" style={{ textDecoration: 'none' }}>
          <Button className="btn-primary">Go Home</Button>
        </Link>
        <Link href="/shop" style={{ textDecoration: 'none' }}>
          <Button variant="outline">Browse Shop</Button>
        </Link>
      </div>

      <div style={{ marginTop: '3rem', paddingTop: '3rem', borderTop: '1px solid rgba(255, 255, 255, 0.1)', maxWidth: '600px' }}>
        <h3 style={{ marginBottom: '1.5rem', textAlign: 'left' }}>Quick Links</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '1rem', textAlign: 'left' }}>
          {[
            { href: '/', label: 'Home' },
            { href: '/shop', label: 'Shop' },
            { href: '/consultation', label: 'Consultation' },
            { href: '/myth-vs-fact', label: 'Myth vs Fact' },
            { href: '/community', label: 'Community' },
            { href: '/cart', label: 'Cart' },
          ].map((link, i) => (
            <Link key={i} href={link.href} style={{ textDecoration: 'none' }}>
              <div
                style={{
                  padding: '1rem',
                  background: '#1A1F26',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '1rem',
                  cursor: 'pointer',
                  transition: 'all 0.3s',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = '#FF5733';
                  e.currentTarget.style.transform = 'translateY(-2px)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                  e.currentTarget.style.transform = 'translateY(0)';
                }}
              >
                {link.label}
              </div>
            </Link>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-20px); }
        }
      `}</style>
    </div>
  );
}
