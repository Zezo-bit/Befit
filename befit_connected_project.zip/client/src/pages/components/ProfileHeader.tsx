import React from 'react';
import { Button } from '@/components/ui/button';
import { Edit2, LogOut, Save, X, Heart, Camera } from 'lucide-react';
import { UserProfile } from '@/contexts/StoreContext';

interface ProfileHeaderProps {
  user: UserProfile;
  isEditing: boolean;
  onEditToggle: () => void;
  onSaveChanges: () => void;
  onCancel: () => void;
  onLogout: () => void;
}

export default function ProfileHeader({
  user,
  isEditing,
  onEditToggle,
  onSaveChanges,
  onCancel,
  onLogout,
}: ProfileHeaderProps) {
  return (
    <section className="relative py-12 bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border-b border-white/10 overflow-hidden">
      {/* Gradient Background Effect */}
      <div className="absolute inset-0 bg-radial-gradient opacity-10 pointer-events-none" />

      <div className="container relative z-10">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 flex-wrap">
          {/* Profile Info */}
          <div className="flex items-center gap-4 w-full md:w-auto">
            {/* Avatar */}
            <div className="relative">
              <div className="w-20 h-20 flex items-center justify-center bg-orange-500/10 rounded-lg border-2 border-orange-500/20 text-4xl">
                👤
              </div>
              {!isEditing && (
                <button className="absolute bottom-0 right-0 bg-orange-600 hover:bg-orange-700 text-white p-2 rounded-md transition-colors">
                  <Camera size={16} />
                </button>
              )}
            </div>

            {/* User Info */}
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <Heart size={24} className="text-orange-600" />
                <h1 className="text-2xl md:text-3xl font-bold">My Health Profile</h1>
              </div>
              <p className="text-gray-400 text-sm">
                {user.name} • Member since{' '}
                {user.createdAt
                  ? new Date(user.createdAt).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                    })
                  : 'Today'}
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 flex-wrap w-full md:w-auto">
            {!isEditing ? (
              <>
                <Button
                  variant="outline"
                  onClick={onEditToggle}
                  className="flex items-center gap-2 flex-1 md:flex-none"
                >
                  <Edit2 size={18} />
                  Edit Profile
                </Button>
                <Button
                  variant="outline"
                  onClick={onLogout}
                  className="flex items-center gap-2 flex-1 md:flex-none"
                >
                  <LogOut size={18} />
                  Logout
                </Button>
              </>
            ) : (
              <>
                <Button
                  onClick={onSaveChanges}
                  className="btn-primary flex items-center gap-2 flex-1 md:flex-none"
                >
                  <Save size={18} />
                  Save Changes
                </Button>
                <Button
                  variant="outline"
                  onClick={onCancel}
                  className="flex items-center gap-2 flex-1 md:flex-none"
                >
                  <X size={18} />
                  Cancel
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
