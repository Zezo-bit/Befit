import React from 'react';
import { Activity } from 'lucide-react';

interface ActivityLevel {
  key: string;
  label: string;
  description: string;
}

interface ActivityLevelSelectorProps {
  isEditing: boolean;
  currentLevel: string | undefined;
  onActivityLevelChange: (level: string) => void;
}

const activityLevels: ActivityLevel[] = [
  { key: 'sedentary', label: 'Sedentary', description: 'Little to no exercise' },
  { key: 'lightly_active', label: 'Lightly Active', description: 'Light exercise 1-3 days/week' },
  { key: 'moderately_active', label: 'Moderately Active', description: 'Moderate exercise 3-5 days/week' },
  { key: 'very_active', label: 'Very Active', description: 'Intense exercise 6-7 days/week' },
];

export default function ActivityLevelSelector({
  isEditing,
  currentLevel,
  onActivityLevelChange,
}: ActivityLevelSelectorProps) {
  if (!isEditing) {
    return (
      <section className="py-8 px-4 md:px-0">
        <div className="container">
          <div className="flex items-center gap-2 mb-6">
            <Activity className="text-orange-600" size={24} />
            <h2 className="text-2xl font-bold">Activity Level</h2>
          </div>

          <div className="bg-slate-900/50 border border-white/10 rounded-lg p-4">
            <p className="text-lg font-semibold capitalize">
              {(currentLevel || 'Not set').replace(/_/g, ' ')}
            </p>
            <p className="text-gray-400 text-sm mt-2">
              {activityLevels.find((l) => l.key === currentLevel)?.description || 'Select an activity level to get started'}
            </p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-8 px-4 md:px-0">
      <div className="container">
        <div className="flex items-center gap-2 mb-6">
          <Activity className="text-orange-600" size={24} />
          <h2 className="text-2xl font-bold">Select Activity Level</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {activityLevels.map((level) => (
            <button
              key={level.key}
              onClick={() => onActivityLevelChange(level.key)}
              className={`p-4 rounded-lg border-2 transition-all duration-200 text-left cursor-pointer group ${
                currentLevel === level.key
                  ? 'border-orange-500 bg-orange-500/15 shadow-lg shadow-orange-500/20'
                  : 'border-white/10 bg-slate-900/50 hover:border-orange-400/50 hover:bg-slate-900/70 hover:shadow-md hover:shadow-orange-500/10'
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <h3 className={`font-semibold transition-colors duration-200 ${
                  currentLevel === level.key ? 'text-orange-400' : 'text-white group-hover:text-orange-300'
                }`}>
                  {level.label}
                </h3>
                <span className={`text-lg font-bold transition-all duration-200 ${
                  currentLevel === level.key 
                    ? 'text-orange-500 scale-125' 
                    : 'text-gray-500 group-hover:text-orange-400'
                }`}>
                  {currentLevel === level.key ? '✓' : '○'}
                </span>
              </div>
              <p className={`text-sm transition-colors duration-200 ${
                currentLevel === level.key ? 'text-orange-300/80' : 'text-gray-400 group-hover:text-gray-300'
              }`}>
                {level.description}
              </p>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
