import React from 'react';
import { CheckCircle, AlertCircle } from 'lucide-react';

interface ProfileCompletionProps {
  completion: number;
}

export default function ProfileCompletion({ completion }: ProfileCompletionProps) {
  const getCompletionColor = () => {
    if (completion >= 80) return 'from-green-500 to-emerald-600';
    if (completion >= 60) return 'from-yellow-500 to-orange-600';
    return 'from-red-500 to-orange-600';
  };

  const getCompletionMessage = () => {
    if (completion >= 80) return 'Profile nearly complete!';
    if (completion >= 60) return 'Good progress! Keep going.';
    return 'Complete your profile for better recommendations.';
  };

  return (
    <section className="py-8 px-4 md:px-0">
      <div className="container">
        <div className="bg-slate-900/50 backdrop-blur border border-white/10 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              {completion >= 80 ? (
                <CheckCircle className="text-green-500" size={24} />
              ) : (
                <AlertCircle className="text-orange-500" size={24} />
              )}
              <h3 className="text-lg font-semibold">Profile Completion</h3>
            </div>
            <span className="text-2xl font-bold text-orange-600">{completion}%</span>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-slate-800 rounded-full h-3 mb-3 overflow-hidden">
            <div
              className={`h-full bg-gradient-to-r ${getCompletionColor()} transition-all duration-500`}
              style={{ width: `${completion}%` }}
            />
          </div>

          <p className="text-gray-400 text-sm">{getCompletionMessage()}</p>
        </div>
      </div>
    </section>
  );
}
