import React from 'react';
import { ShoppingBag, Lightbulb, ShoppingCart } from 'lucide-react';
import { useStore } from '@/contexts/StoreContext';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface RecommendationsSectionProps {
  products: string[];
  tips: string[];
}

export default function RecommendationsSection({
  products,
  tips,
}: RecommendationsSectionProps) {
  const { products: allProducts, addToCart } = useStore();
  const [, setLocation] = useLocation();

  const handleAddToCart = (productName: string) => {
    // Find the product in our catalog by name
    const product = allProducts.find(p => p.name.toLowerCase() === productName.toLowerCase() || productName.toLowerCase().includes(p.name.toLowerCase()));
    
    if (product) {
      addToCart({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        quantity: 1
      });
      toast.success(`${product.name} added to cart`);
    } else {
      toast.error('Product details not found. Please visit the shop.');
    }
  };

  return (
    <section className="py-8 px-4 md:px-0">
      <div className="container">
        <h2 className="text-2xl font-bold mb-6">Personalized Recommendations</h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recommended Products */}
          <div className="bg-slate-900/50 border border-white/10 rounded-lg p-6">
            <div className="flex items-center gap-2 mb-4">
              <ShoppingBag className="text-orange-600" size={24} />
              <h3 className="text-xl font-semibold">Recommended Products</h3>
            </div>

            <div className="space-y-3">
              {products.map((productName, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg hover:bg-slate-800 transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-orange-600 rounded-full flex-shrink-0" />
                    <span className="text-gray-200">{productName}</span>
                  </div>
                  <Button 
                    size="sm" 
                    variant="ghost" 
                    className="opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity text-orange-600 hover:text-orange-500 hover:bg-orange-600/10 flex items-center gap-2"
                    onClick={() => handleAddToCart(productName)}
                  >
                    <ShoppingCart size={16} />
                    <span className="hidden sm:inline">Add to Cart</span>
                  </Button>
                </div>
              ))}
            </div>
          </div>

          {/* Health Tips */}
          <div className="bg-slate-900/50 border border-white/10 rounded-lg p-6">
            <div className="flex items-center gap-2 mb-4">
              <Lightbulb className="text-orange-600" size={24} />
              <h3 className="text-xl font-semibold">Health Tips</h3>
            </div>

            <div className="space-y-2">
              {tips.map((tip, index) => (
                <div
                  key={index}
                  className="flex items-start gap-3 p-3 bg-slate-800/50 rounded-lg hover:bg-slate-800 transition-colors"
                >
                  <div className="w-2 h-2 bg-green-500 rounded-full flex-shrink-0 mt-1" />
                  <span className="text-gray-200 text-sm">{tip}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
