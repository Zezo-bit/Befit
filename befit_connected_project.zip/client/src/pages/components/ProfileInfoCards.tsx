import React from 'react';
import { Heart, Activity, Target, TrendingUp } from 'lucide-react';
import { UserProfile } from '@/contexts/StoreContext';

interface ProfileInfoCardsProps {
  user: UserProfile;
  isEditing: boolean;
  editData: UserProfile;
  onEditChange: (field: string, value: any) => void;
}

interface InfoCardProps {
  label: string;
  value: React.ReactNode;
  icon: React.ReactNode;
  unit?: string;
}

function InfoCard({ label, value, icon, unit }: InfoCardProps) {
  return (
    <div className="bg-slate-900/50 border border-white/10 rounded-lg p-4 flex items-start gap-3">
      <div className="text-orange-600 flex-shrink-0">{icon}</div>
      <div className="flex-1 min-w-0">
        <p className="text-gray-400 text-sm font-medium mb-1">{label}</p>
        <div className="flex items-baseline gap-1">
          <p className="text-lg font-semibold truncate">{value}</p>
          {unit && <span className="text-gray-500 text-sm">{unit}</span>}
        </div>
      </div>
    </div>
  );
}

export default function ProfileInfoCards({
  user,
  isEditing,
  editData,
  onEditChange,
}: ProfileInfoCardsProps) {
  return (
    <section className="py-8 px-4 md:px-0">
      <div className="container">
        <h2 className="text-2xl font-bold mb-6">Personal Information</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Name */}
          <div>
            <label className="block text-sm font-medium mb-2">Name</label>
            {isEditing ? (
              <input
                type="text"
                value={editData.name || ''}
                onChange={(e) => onEditChange('name', e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-white focus:border-orange-500 focus:outline-none transition-colors"
              />
            ) : (
              <InfoCard
                label="Name"
                value={user.name}
                icon={<Heart size={20} />}
              />
            )}
          </div>

          {/* Age */}
          <div>
            <label className="block text-sm font-medium mb-2">Age</label>
            {isEditing ? (
              <input
                type="number"
                value={editData.age || ''}
                onChange={(e) => onEditChange('age', parseInt(e.target.value))}
                className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-white focus:border-orange-500 focus:outline-none transition-colors"
              />
            ) : (
              <InfoCard
                label="Age"
                value={user.age || '—'}
                icon={<Activity size={20} />}
                unit="years"
              />
            )}
          </div>

          {/* Weight */}
          <div>
            <label className="block text-sm font-medium mb-2">Weight</label>
            {isEditing ? (
              <input
                type="number"
                value={editData.weight || ''}
                onChange={(e) => onEditChange('weight', parseInt(e.target.value))}
                className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-white focus:border-orange-500 focus:outline-none transition-colors"
              />
            ) : (
              <InfoCard
                label="Weight"
                value={user.weight || '—'}
                icon={<TrendingUp size={20} />}
                unit="kg"
              />
            )}
          </div>

          {/* Height */}
          <div>
            <label className="block text-sm font-medium mb-2">Height</label>
            {isEditing ? (
              <input
                type="number"
                value={editData.height || ''}
                onChange={(e) => onEditChange('height', parseInt(e.target.value))}
                className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-white focus:border-orange-500 focus:outline-none transition-colors"
              />
            ) : (
              <InfoCard
                label="Height"
                value={user.height || '—'}
                icon={<TrendingUp size={20} />}
                unit="cm"
              />
            )}
          </div>

          {/* Fitness Goal */}
          <div className="md:col-span-2">
            <label className="block text-sm font-medium mb-2">Fitness Goal</label>
            {isEditing ? (
              <select
                value={editData.goal || ''}
                onChange={(e) => onEditChange('goal', e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-white focus:border-orange-500 focus:outline-none transition-colors"
              >
                <option value="">Select a goal</option>
                <option value="muscle_gain">Build Muscle</option>
                <option value="weight_loss">Lose Weight</option>
                <option value="endurance">Improve Endurance</option>
                <option value="general_health">General Health</option>
              </select>
            ) : (
              <InfoCard
                label="Goal"
                value={(user.goal || '').replace(/_/g, ' ').toUpperCase()}
                icon={<Target size={20} />}
              />
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
