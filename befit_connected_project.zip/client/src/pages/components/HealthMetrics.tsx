import React from 'react';
import { Activity, Flame, Droplet, TrendingUp } from 'lucide-react';
import { UserProfile } from '@/contexts/StoreContext';

interface HealthMetricsProps {
  user: UserProfile;
  bmi: string | null;
  bmiCategory: { category: string; color: string; bg: string } | null;
  bmr: number | null;
  tdee: number | null;
}

interface MetricCardProps {
  label: string;
  value: string | number;
  unit: string;
  icon: React.ReactNode;
  color: string;
  bgColor: string;
}

function MetricCard({ label, value, unit, icon, color, bgColor }: MetricCardProps) {
  return (
    <div className={`${bgColor} border border-white/10 rounded-lg p-4 md:p-6`}>
      <div className="flex items-start justify-between mb-3">
        <h4 className="text-gray-400 text-sm font-medium">{label}</h4>
        <div className={`${color}`}>{icon}</div>
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-2xl md:text-3xl font-bold">{value}</span>
        <span className="text-gray-500 text-sm">{unit}</span>
      </div>
    </div>
  );
}

export default function HealthMetrics({
  user,
  bmi,
  bmiCategory,
  bmr,
  tdee,
}: HealthMetricsProps) {
  return (
    <section className="py-8 px-4 md:px-0">
      <div className="container">
        <h2 className="text-2xl font-bold mb-6">Health Metrics</h2>

        {/* Main Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <MetricCard
            label="BMI"
            value={bmi || '—'}
            unit={bmi ? 'kg/m²' : ''}
            icon={<Activity size={20} />}
            color="text-blue-400"
            bgColor="bg-slate-900/50"
          />
          <MetricCard
            label="BMI Category"
            value={bmiCategory?.category || '—'}
            unit=""
            icon={<TrendingUp size={20} />}
            color={`text-[${bmiCategory?.color}]`}
            bgColor="bg-slate-900/50"
          />
          <MetricCard
            label="BMR"
            value={bmr || '—'}
            unit={bmr ? 'kcal/day' : ''}
            icon={<Flame size={20} />}
            color="text-orange-400"
            bgColor="bg-slate-900/50"
          />
          <MetricCard
            label="TDEE"
            value={tdee || '—'}
            unit={tdee ? 'kcal/day' : ''}
            icon={<Droplet size={20} />}
            color="text-green-400"
            bgColor="bg-slate-900/50"
          />
        </div>

        {/* BMI Category Details */}
        {bmiCategory && (
          <div
            className="p-4 rounded-lg border border-white/10"
            style={{ backgroundColor: bmiCategory.bg }}
          >
            <p className="text-sm">
              <span style={{ color: bmiCategory.color }} className="font-semibold">
                {bmiCategory.category}:
              </span>
              <span className="text-gray-400 ml-2">
                {bmiCategory.category === 'Underweight' &&
                  'Consider consulting a nutritionist for a healthy weight gain plan.'}
                {bmiCategory.category === 'Normal' &&
                  'Great! You are at a healthy weight. Maintain your current lifestyle.'}
                {bmiCategory.category === 'Overweight' &&
                  'Consider increasing physical activity and adjusting your diet.'}
                {bmiCategory.category === 'Obese' &&
                  'Consult with a healthcare professional for personalized guidance.'}
              </span>
            </p>
          </div>
        )}
      </div>
    </section>
  );
}
