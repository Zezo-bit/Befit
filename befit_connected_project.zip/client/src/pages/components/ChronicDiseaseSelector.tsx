import React from 'react';
import { AlertCircle } from 'lucide-react';

interface ChronicDisease {
  key: string;
  label: string;
  icon: string;
}

interface ChronicDiseaseSelectorProps {
  isEditing: boolean;
  selectedDiseases: string[] | undefined;
  onDiseaseToggle: (disease: string) => void;
}

const chronicDiseases: ChronicDisease[] = [
  { key: 'diabetes', label: 'Diabetes', icon: '🩺' },
  { key: 'hypertension', label: 'High Blood Pressure', icon: '💓' },
  { key: 'heart_disease', label: 'Heart Disease', icon: '❤️' },
  { key: 'thyroid', label: 'Thyroid Disorder', icon: '🧬' },
  { key: 'kidney_disease', label: 'Kidney Disease', icon: '🫘' },
  { key: 'liver_disease', label: 'Liver Disease', icon: '🫀' },
  { key: 'celiac', label: 'Celiac Disease', icon: '🌾' },
  { key: 'ibs', label: 'IBS', icon: '🔄' },
];

export default function ChronicDiseaseSelector({
  isEditing,
  selectedDiseases,
  onDiseaseToggle,
}: ChronicDiseaseSelectorProps) {
  const diseases = selectedDiseases || [];

  if (!isEditing) {
    return (
      <section className="py-8 px-4 md:px-0">
        <div className="container">
          <div className="flex items-center gap-2 mb-6">
            <AlertCircle className="text-orange-600" size={24} />
            <h2 className="text-2xl font-bold">Medical Conditions</h2>
          </div>

          {diseases.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {diseases.map((condition) => {
                const disease = chronicDiseases.find((d) => d.key === condition);
                return (
                  <div
                    key={condition}
                    className="bg-orange-500/10 border border-orange-500/30 rounded-full px-4 py-2 flex items-center gap-2"
                  >
                    <span className="text-lg">{disease?.icon}</span>
                    <span className="text-sm font-medium">{disease?.label}</span>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-gray-400">No medical conditions reported</p>
          )}
        </div>
      </section>
    );
  }

  return (
    <section className="py-8 px-4 md:px-0">
      <div className="container">
        <div className="flex items-center gap-2 mb-6">
          <AlertCircle className="text-orange-600" size={24} />
          <h2 className="text-2xl font-bold">Medical Conditions</h2>
        </div>

        <p className="text-gray-400 text-sm mb-4">Select any conditions that apply to you for personalized recommendations</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {chronicDiseases.map((disease) => {
            const isSelected = diseases.includes(disease.key);
            return (
              <button
                key={disease.key}
                onClick={() => onDiseaseToggle(disease.key)}
                className={`p-4 rounded-lg border-2 transition-all duration-200 text-center cursor-pointer group relative ${
                  isSelected
                    ? 'border-orange-500 bg-orange-500/15 shadow-lg shadow-orange-500/20'
                    : 'border-white/10 bg-slate-900/50 hover:border-orange-400/50 hover:bg-slate-900/70 hover:shadow-md hover:shadow-orange-500/10'
                }`}
              >
                {/* Selection indicator checkmark */}
                {isSelected && (
                  <div className="absolute top-2 right-2 w-5 h-5 bg-orange-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                    ✓
                  </div>
                )}
                
                <div className={`text-3xl mb-2 transition-transform duration-200 ${
                  isSelected ? 'scale-110' : 'group-hover:scale-110'
                }`}>
                  {disease.icon}
                </div>
                
                <p className={`text-sm font-medium transition-colors duration-200 ${
                  isSelected 
                    ? 'text-orange-400' 
                    : 'text-white group-hover:text-orange-300'
                }`}>
                  {disease.label}
                </p>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
