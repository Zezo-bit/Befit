import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export default function AIConsultation() {
  const [messages, setMessages] = useState<Array<{ role: 'ai' | 'user'; content: string }>>([
    {
      role: 'ai',
      content:
        "Hello! I'm your BeFit AI health consultant. I've analyzed your profile and see that you're aiming for Lean Muscle Gain with Lactose Intolerance. How can I help you today? Feel free to ask about nutrition, supplements, training, or any health-related questions!",
    },
  ]);

  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const suggestionChips = [
    'Show lactose-free protein',
    'Is creatine safe for me?',
    'Best pre-workout for hypertension',
    'Weight loss tips',
    'Sleep & recovery',
    'Cardio vs strength training',
    'Home workouts',
    'Abs training',
    'Leg day routine',
    'Motivation tips',
  ];

  // Massively expanded knowledge base with 40+ topics
  const knowledgeBase = [
    // Protein & Nutrition
    {
      keywords: ['protein', 'whey', 'isolate', 'plant-based'],
      response: "Based on your lactose intolerance, I recommend Whey Protein Isolate (99% lactose-free) or Plant-Based options like Pea, Soy, or Hemp protein. Aim for 1.6-2.2g per kg of body weight daily for lean muscle gain. I've updated your recommendations in the shop!",
    },
    // Creatine
    {
      keywords: ['creatine', 'creatine monohydrate'],
      response: "Creatine is generally safe and highly researched for lean muscle gain. It helps with strength and muscle endurance. Since you have mild hypertension, ensure you stay well-hydrated (3-4L water daily) and always consult your doctor before starting. Standard dose: 5g daily.",
    },
    // Pre-workout
    {
      keywords: ['pre-workout', 'caffeine', 'energy'],
      response: "For hypertension, look for stim-free pre-workouts or those with minimal caffeine (under 100mg). Ingredients like Citrulline Malate (6-8g), Beta-Alanine, and Beetroot Extract are excellent for pumps and endurance without the jitters.",
    },
    // Weight Loss
    {
      keywords: ['weight loss', 'fat loss', 'lose weight', 'burn fat', 'تنحيف', 'تخسيس'],
      response: "To lose weight effectively, create a sustainable calorie deficit of 300-500 kcal below maintenance. Prioritize high-protein meals (1.6g per kg) to preserve muscle, combine strength training with moderate cardio, and aim for 0.5-1kg loss per week.",
    },
    // Muscle Building
    {
      keywords: ['muscle gain', 'bulk', 'build muscle', 'hypertrophy', 'عضلات'],
      response: "For muscle building, you need a slight calorie surplus of 200-300 kcal above maintenance. Consume 1.6-2.2g protein per kg of body weight, train with progressive overload, and ensure adequate recovery with 7-9 hours of sleep.",
    },
    // Keto Diet
    {
      keywords: ['keto', 'ketogenic', 'low carb', 'كيتو'],
      response: "The Keto diet focuses on high fats, moderate protein, and very low carbs (usually <50g daily). It's effective for fat loss but can be challenging to maintain. Important: ensure adequate electrolytes (sodium, potassium, magnesium) and consult your doctor given your hypertension.",
    },
    // Intermittent Fasting
    {
      keywords: ['fasting', 'intermittent fasting', '16/8', 'صيام'],
      response: "Intermittent fasting (like 16/8 method) is a great tool for calorie control and can improve insulin sensitivity. It doesn't magically burn fat but helps manage hunger. Start with 12/12 and gradually increase the fasting window.",
    },
    // Vitamins & Supplements
    {
      keywords: ['vitamins', 'omega 3', 'vitamin d', 'multivitamin', 'فيتامينات'],
      response: "Supplements should enhance a solid diet. Omega-3 supports heart and joint health (especially important with hypertension). Vitamin D is crucial if you have limited sun exposure. Consider Magnesium for muscle recovery and blood pressure management.",
    },
    // Sleep & Recovery
    {
      keywords: ['sleep', 'recovery', 'rest', 'tired', 'نوم', 'استشفاء'],
      response: "Recovery is where growth happens! Aim for 7-9 hours of quality sleep. Lack of sleep increases cortisol, hindering fat loss and muscle gain. Try to maintain consistent sleep schedules and avoid screens 1 hour before bed.",
    },
    // Cardio vs Strength
    {
      keywords: ['cardio', 'weights', 'strength training', 'running', 'كارديو'],
      response: "Strength training should be your foundation to build muscle and boost metabolism. Cardio is excellent for cardiovascular health and calorie burn. For your goals: 3-4 days strength training + 2-3 days moderate cardio is ideal.",
    },
    // Hydration
    {
      keywords: ['water', 'hydration', 'drink', 'ماء', 'شرب'],
      response: "Aim for 3-4 liters of water daily, especially if you're active. Dehydration can lead to strength loss, decreased focus, and elevated blood pressure. A good indicator: your urine should be light yellow.",
    },
    // Lactose Intolerance
    {
      keywords: ['lactose', 'dairy', 'milk', 'cheese', 'لاكتوز'],
      response: "With lactose intolerance, avoid regular milk, cream, and soft cheeses. Opt for lactose-free milk, Greek yogurt (low lactose), hard cheeses, or plant-based alternatives. Protein powder isolates are also safe options.",
    },
    // Hypertension
    {
      keywords: ['blood pressure', 'hypertension', 'pressure', 'ضغط'],
      response: "Managing hypertension with fitness: reduce sodium intake, maintain a healthy weight, do regular cardio, manage stress, and limit caffeine. Strength training is safe but avoid straining hard. Always monitor your BP and consult your doctor.",
    },
    // Meal Planning
    {
      keywords: ['meal plan', 'nutrition plan', 'diet', 'eating', 'خطة غذائية'],
      response: "A good meal plan includes: lean proteins (chicken, fish, eggs), complex carbs (oats, rice, sweet potatoes), healthy fats (olive oil, nuts), and vegetables. Eat 4-5 meals daily spaced 3-4 hours apart for optimal muscle building.",
    },
    // Training Frequency
    {
      keywords: ['training frequency', 'how many times', 'workout days', 'تمارين'],
      response: "For lean muscle gain: train 4-5 days per week, focusing on compound movements (squats, deadlifts, bench press). Each muscle group should be trained 2x per week. Rest days are crucial for recovery!",
    },
    // Post-Workout
    {
      keywords: ['post-workout', 'after workout', 'recovery drink', 'بعد التمرين'],
      response: "Post-workout nutrition is key: consume protein (20-40g) and carbs (40-80g) within 2 hours after training. This replenishes glycogen and supports muscle protein synthesis. A protein shake with banana and oats works great!",
    },
    // Injury Prevention
    {
      keywords: ['injury', 'pain', 'sore', 'prevention', 'إصابة'],
      response: "Prevent injuries by: warming up properly, using correct form, progressing gradually, and not skipping rest days. If you experience sharp pain, stop and consult a professional. Foam rolling and stretching help with recovery.",
    },
    // Metabolism
    {
      keywords: ['metabolism', 'metabolic rate', 'burn calories', 'عملية الأيض'],
      response: "Your metabolic rate depends on age, gender, weight, and activity level. Strength training increases muscle mass, which boosts resting metabolism. Eating adequate protein also increases thermic effect of food.",
    },
    // Supplements Safety
    {
      keywords: ['supplement safety', 'side effects', 'safe', 'آمن'],
      response: "Most common supplements (protein, creatine, vitamins) are safe when used as directed. However, always check for quality certifications (NSF, USP), avoid proprietary blends, and consult your doctor, especially with your hypertension.",
    },
    // General Greeting
    {
      keywords: ['hi', 'hello', 'hey', 'thanks', 'سلام', 'مرحبا'],
      response: "Great! I'm here to help with any fitness or nutrition questions. Whether it's about your lean muscle gain goals, managing your lactose intolerance, or handling hypertension, feel free to ask!",
    },
    // Plateau / Weight Stagnation
    {
      keywords: ['plateau', 'stuck', 'not losing weight', 'no progress', 'ثبات', 'توقف'],
      response: "Hitting a plateau is normal! Your body adapts to consistent routines. Try: changing your exercises, increasing intensity, adjusting calories (drop 100-200 kcal), or adding more cardio. Plateaus usually last 2-4 weeks before progress resumes.",
    },
    // Home Workouts
    {
      keywords: ['home workout', 'no gym', 'bodyweight', 'home exercise', 'تمارين منزلية'],
      response: "Great home workout options: push-ups, squats, lunges, planks, and burpees. Use resistance bands or dumbbells if available. Focus on progressive overload by increasing reps or sets. YouTube has excellent bodyweight training routines!",
    },
    // BCAA & Amino Acids
    {
      keywords: ['bcaa', 'amino acids', 'eaa', 'essential amino acids'],
      response: "BCAAs (Branched-Chain Amino Acids) are useful for muscle preservation during fasting or intense training. However, whole protein sources are more cost-effective. EAAs (Essential Amino Acids) are superior to BCAAs. Prioritize whole foods first!",
    },
    // Stretching & Flexibility
    {
      keywords: ['stretching', 'flexibility', 'mobility', 'tight', 'مرونة'],
      response: "Stretching improves flexibility and reduces injury risk. Do dynamic stretches before workouts and static stretches after. Aim for 10-15 minutes of stretching 3-4 times weekly. Yoga is excellent for overall mobility and stress relief.",
    },
    // Stress Management
    {
      keywords: ['stress', 'anxiety', 'cortisol', 'mental health', 'ضغط نفسي'],
      response: "High stress increases cortisol, hindering fat loss and muscle gain. Manage stress through: meditation, deep breathing, yoga, regular exercise, adequate sleep, and social connections. Even 10 minutes of daily meditation helps!",
    },
    // Alcohol & Fitness
    {
      keywords: ['alcohol', 'beer', 'wine', 'drinking', 'كحول'],
      response: "Alcohol dehydrates you and impairs muscle protein synthesis. Occasional moderate drinking is fine, but limit to 1-2 drinks per week for optimal results. Alcohol also adds empty calories without nutritional value.",
    },
    // Abs & Core Training
    {
      keywords: ['abs', 'six pack', 'core', 'abdominal', 'عضلات البطن'],
      response: "Visible abs require low body fat (10-15% for men). Focus on: compound movements, calorie deficit, and direct core work (planks, cable crunches). Abs are built in the kitchen more than the gym! Consistency with diet is key.",
    },
    // Leg Day
    {
      keywords: ['leg day', 'legs', 'squats', 'deadlifts', 'تمارين الأرجل'],
      response: "Leg day is crucial! Compound movements like squats and deadlifts build strength and boost metabolism. Include: squats, deadlifts, lunges, leg press, and leg curls. Train legs 1-2x weekly. Don't skip leg day!",
    },
    // Back & Posture
    {
      keywords: ['back', 'posture', 'back pain', 'spine', 'الظهر'],
      response: "Good posture prevents back pain and improves performance. Include back exercises: rows, pull-ups, lat pulldowns. Strengthen your core and avoid excessive forward bending. If you have chronic back pain, consult a physical therapist.",
    },
    // Chest & Upper Body
    {
      keywords: ['chest', 'bench press', 'pecs', 'upper body', 'الصدر'],
      response: "Build chest with: bench press, incline press, dumbbell flyes, and push-ups. Train chest 1-2x weekly with adequate rest between sessions. Progressive overload is key—gradually increase weight or reps each week.",
    },
    // Shoulders & Arms
    {
      keywords: ['shoulders', 'arms', 'biceps', 'triceps', 'deltoids', 'الكتفين'],
      response: "Shoulder health is crucial. Include: overhead press, lateral raises, and face pulls. For arms: barbell curls, tricep dips, and overhead extensions. Train shoulders and arms 1-2x weekly. Avoid heavy weight with poor form.",
    },
    // Calorie Counting
    {
      keywords: ['calorie counting', 'calories', 'macros', 'tracking', 'عد السعرات'],
      response: "Tracking calories helps you stay accountable. Use apps like MyFitnessPal. For lean muscle gain: eat 200-300 kcal above maintenance. For fat loss: eat 300-500 kcal below. Consistency matters more than perfection!",
    },
    // Carbs Timing
    {
      keywords: ['carbs', 'carbohydrates', 'timing', 'before workout', 'الكربوهيدرات'],
      response: "Carbs provide energy for workouts. Eat carbs 1-2 hours before training for sustained energy. Post-workout carbs (40-80g) replenish glycogen. Don't fear carbs—they're essential for performance and recovery!",
    },
    // Fats & Hormones
    {
      keywords: ['fats', 'healthy fats', 'hormones', 'testosterone', 'الدهون'],
      response: "Healthy fats are essential for hormone production, including testosterone. Include: olive oil, nuts, avocados, fatty fish. Aim for 0.8-1.2g fat per kg of body weight daily. Don't go too low on fats!",
    },
    // Fiber & Digestion
    {
      keywords: ['fiber', 'digestion', 'constipation', 'gut health', 'الألياف'],
      response: "Fiber aids digestion and keeps you full longer. Aim for 25-35g daily from: vegetables, fruits, whole grains, and legumes. Increase fiber gradually to avoid bloating. Adequate water intake is important too!",
    },
    // Meal Frequency
    {
      keywords: ['meal frequency', 'how many meals', 'eating frequency', 'عدد الوجبات'],
      response: "Meal frequency matters less than total calories. Eat 3-5 meals daily based on your preference. Some prefer 3 large meals, others prefer 5-6 smaller meals. Choose what keeps you satisfied and consistent!",
    },
    // Pre-Workout Meal
    {
      keywords: ['pre-workout meal', 'before workout', 'pre-workout nutrition', 'قبل التمرين'],
      response: "Eat 1-2 hours before training: carbs + protein (e.g., oatmeal with banana and protein powder). This provides sustained energy and prevents muscle breakdown. Avoid heavy, fatty foods that cause discomfort.",
    },
    // Supplements Worth Taking
    {
      keywords: ['best supplements', 'worth taking', 'supplement recommendations', 'مكملات مهمة'],
      response: "Top supplements: Whey Protein (convenience), Creatine (strength), Vitamin D (if deficient), Omega-3 (heart health), Multivitamin (insurance). Everything else is optional. Prioritize diet and training first!",
    },
    // Fat Burners
    {
      keywords: ['fat burner', 'thermogenic', 'weight loss supplement', 'حرق الدهون'],
      response: "Fat burners have minimal effect without diet and exercise. Caffeine and green tea extract provide slight metabolic boost. Focus on: calorie deficit, protein intake, and strength training. These are more effective than any supplement!",
    },
    // Protein Timing
    {
      keywords: ['protein timing', 'protein window', 'anabolic window', 'وقت البروتين'],
      response: "Protein timing is less critical than total daily intake. Consume 20-40g protein per meal spread throughout the day. Post-workout protein (within 2 hours) is beneficial but not mandatory. Total daily protein matters most!",
    },
    // Women's Fitness
    {
      keywords: ['women', 'female', 'women fitness', 'female training', 'النساء'],
      response: "Women benefit from the same training principles as men: progressive overload, adequate protein, and calorie management. Hormonal cycles may affect performance—adjust intensity accordingly. Strength training won't make you bulky!",
    },
    // Age & Fitness
    {
      keywords: ['age', 'older', 'young', 'aging', 'العمر'],
      response: "Fitness is important at any age! Older adults should focus on: strength training (prevents muscle loss), flexibility work, and adequate protein. Younger people can handle higher intensity. Adjust based on recovery and injury history.",
    },
    // Genetics & Fitness
    {
      keywords: ['genetics', 'genetic', 'body type', 'ectomorph', 'mesomorph', 'endomorph'],
      response: "Genetics influence muscle-building potential and fat distribution, but don't determine your success. Consistency beats genetics! Train hard, eat right, and sleep well. Your genetics set the ceiling, not the floor.",
    },
    // Motivation & Consistency
    {
      keywords: ['motivation', 'consistency', 'discipline', 'motivation tips', 'الدافعية'],
      response: "Motivation fades—build discipline instead! Create habits: schedule workouts, prep meals, track progress. Find a workout buddy or coach. Remember your 'why.' Progress takes time, but consistency compounds into amazing results!",
    },
    // Cheat Meals & Refeed
    {
      keywords: ['cheat meal', 'refeed', 'cheat day', 'treat meal', 'وجبة حرة'],
      response: "Occasional cheat meals (1-2x weekly) are fine and help with adherence. They don't ruin progress if your overall diet is good. Refeeds (higher carb days) can boost metabolism during prolonged diets. Enjoy food guilt-free!",
    },
    // Supplements & Lactose
    {
      keywords: ['lactose free supplement', 'protein lactose', 'dairy free', 'بدائل خالية من اللاكتوز'],
      response: "For your lactose intolerance: choose Whey Protein Isolate (99% lactose-free), plant-based proteins (pea, soy, hemp), or lactose-free protein blends. Always check labels! Many supplements are naturally lactose-free.",
    },
    // Workout Intensity
    {
      keywords: ['intensity', 'high intensity', 'hiit', 'intense workout', 'الشدة'],
      response: "Higher intensity doesn't always mean better results. Focus on: progressive overload, proper form, and consistency. HIIT is great for cardio but shouldn't replace strength training. Balance intensity with recovery!",
    },
    // Deload Week
    {
      keywords: ['deload', 'deload week', 'recovery week', 'light week'],
      response: "Deload weeks (every 4-6 weeks) reduce volume/intensity by 40-50%. This allows recovery, prevents burnout, and reduces injury risk. Use lighter weights, fewer sets, and focus on form. You'll come back stronger!",
    },
    // Nutrition Timing
    {
      keywords: ['nutrition timing', 'meal timing', 'when to eat', 'وقت الأكل'],
      response: "Total daily calories matter most, but timing helps: eat carbs around workouts, spread protein throughout the day, and don't skip meals. Consistency in timing helps with hunger management and energy levels.",
    },
    // Supplements & Hypertension
    {
      keywords: ['supplement hypertension', 'blood pressure supplement', 'safe supplement'],
      response: "With hypertension, avoid high-caffeine supplements and stimulants. Safe options: Omega-3 (heart health), Magnesium (BP management), L-Arginine (vasodilation). Always consult your doctor before new supplements!",
    },
    // Progressive Overload
    {
      keywords: ['progressive overload', 'increase weight', 'progression', 'تصعيد التمارين'],
      response: "Progressive overload is the key to continuous progress! Increase weight, reps, sets, or decrease rest periods each week. Track your workouts to ensure progression. Small improvements compound into massive strength gains!",
    },
    // Form & Technique
    {
      keywords: ['form', 'technique', 'proper form', 'form check', 'الشكل الصحيح'],
      response: "Perfect form prevents injuries and maximizes muscle engagement. Use lighter weight to master form first. Film yourself or ask for feedback. Quality reps with proper form beat heavy weight with poor form every time!",
    },
    // Warm-up & Cool-down
    {
      keywords: ['warm up', 'warm-up', 'cool down', 'cool-down', 'الإحماء'],
      response: "Always warm up for 5-10 minutes before training: light cardio + dynamic stretches. Cool down for 5 minutes: light movement + static stretches. This improves performance, prevents injury, and aids recovery.",
    },
    // Rest Days
    {
      keywords: ['rest day', 'rest days', 'active recovery', 'off day', 'يوم راحة'],
      response: "Rest days are essential for muscle growth and preventing burnout. Take 1-2 complete rest days weekly or do light active recovery (walking, yoga). Your muscles grow during rest, not during training!",
    },
    // Tracking Progress
    {
      keywords: ['track progress', 'progress tracking', 'measure', 'progress photos', 'تتبع التقدم'],
      response: "Track progress through: weight, body measurements, strength levels, and photos. Weigh yourself weekly (same time/day). Take progress photos monthly. Don't obsess over daily weight fluctuations—focus on trends!",
    },
  ];

  const getAIResponse = (userMessage: string): string => {
    const msg = userMessage.toLowerCase();
    
    // Check against knowledge base
    for (const item of knowledgeBase) {
      for (const keyword of item.keywords) {
        if (msg.includes(keyword.toLowerCase())) {
          return item.response;
        }
      }
    }

    // Fallback response
    return "That's a great question! Based on your profile (Lean Muscle Gain with Lactose Intolerance and mild Hypertension), I'd suggest focusing on consistent protein intake from lactose-free sources, monitoring your blood pressure during heavy lifts, and maintaining proper hydration. Is there anything specific about your diet, training, or supplements you'd like to know more about?";
  };

  const handleSend = (text?: string) => {
    const messageToSend = text || inputValue;
    if (messageToSend.trim()) {
      // Add user message
      setMessages(prev => [...prev, { role: 'user', content: messageToSend }]);
      setInputValue('');
      
      // Simulate realistic AI response
      setIsTyping(true);
      
      // Short delay for realism
      setTimeout(() => {
        setIsTyping(false);
        const response = getAIResponse(messageToSend);
        setMessages(prev => [...prev, { role: 'ai', content: response }]);
      }, 800); 
    }
  };

  const handleSuggestion = (suggestion: string) => {
    handleSend(suggestion);
  };

  const handleExport = () => {
    toast.info('Chat exported as PDF');
  };

  // Auto-scroll to latest message within the container only
  useEffect(() => {
    if (messagesEndRef.current) {
      const container = messagesEndRef.current.parentElement;
      if (container) {
        container.scrollTo({
          top: container.scrollHeight,
          behavior: 'smooth'
        });
      }
    }
  }, [messages]);

  return (
    <div style={{ minHeight: '100vh', padding: '2rem 0', background: '#0f1419' }}>
      <div className="container">
        <div
          style={{
            maxWidth: '900px',
            margin: '0 auto',
            background: '#1A1F26',
            borderRadius: '1rem',
            border: '1px solid rgba(255, 255, 255, 0.1)',
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column',
            height: '700px',
            boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3)',
          }}
        >
          {/* Chat Header */}
          <div
            style={{
              padding: '1.5rem 2rem',
              background: '#161B22',
              borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
              display: 'flex',
              alignItems: 'center',
              gap: '1rem',
            }}
          >
            <div
              style={{
                background: '#FF5733',
                width: '40px',
                height: '40px',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                fontSize: '1.2rem',
              }}
            >
              <i className="fas fa-robot"></i>
            </div>
            <div>
              <h4 style={{ margin: 0 }}>BeFit Smart AI</h4>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.8rem', color: '#b0b0b0' }}>
                <div
                  style={{
                    width: '10px',
                    height: '10px',
                    background: '#10B981',
                    borderRadius: '50%',
                  }}
                ></div>
                Online • Science-Backed Expert
              </div>
            </div>
            <Button onClick={handleExport} variant="outline" style={{ marginLeft: 'auto', fontSize: '0.85rem' }}>
              Export Chat
            </Button>
          </div>

          {/* Chat Messages */}
          <div
            style={{
              flex: 1,
              padding: '2rem',
              overflowY: 'auto',
              display: 'flex',
              flexDirection: 'column',
              gap: '1.5rem',
            }}
          >
            {messages.map((message, index) => (
              <div
                key={index}
                style={{
                  display: 'flex',
                  justifyContent: message.role === 'user' ? 'flex-end' : 'flex-start',
                }}
              >
                <div
                  style={{
                    maxWidth: '80%',
                    padding: '1.25rem',
                    borderRadius: '1rem',
                    lineHeight: 1.6,
                    background: message.role === 'user' ? '#FF5733' : '#2D3139',
                    color: message.role === 'user' ? 'white' : '#e0e0e0',
                    border: message.role === 'user' ? 'none' : '1px solid rgba(255, 255, 255, 0.1)',
                    borderBottomLeftRadius: message.role === 'user' ? '1rem' : '0',
                    borderBottomRightRadius: message.role === 'user' ? '0' : '1rem',
                  }}
                >
                  {message.content}
                </div>
              </div>
            ))}

            {isTyping && (
              <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
                <div style={{ background: '#2D3139', padding: '1rem', borderRadius: '1rem', color: '#b0b0b0', fontSize: '0.9rem' }}>
                  <i className="fas fa-circle-notch fa-spin" style={{ marginRight: '0.5rem' }}></i>
                  AI is thinking...
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Chat Input */}
          <div
            style={{
              padding: '1.5rem 2rem',
              background: '#161B22',
              borderTop: '1px solid rgba(255, 255, 255, 0.1)',
            }}
          >
            <div
              style={{
                display: 'flex',
                gap: '0.75rem',
                marginBottom: '1rem',
                flexWrap: 'wrap',
              }}
            >
              {suggestionChips.map((chip, i) => (
                <button
                  key={i}
                  onClick={() => handleSuggestion(chip)}
                  style={{
                    background: 'rgba(255, 87, 51, 0.1)',
                    color: '#FF5733',
                    padding: '0.5rem 1rem',
                    border: '1px solid rgba(255, 87, 51, 0.2)',
                    borderRadius: '2rem',
                    fontSize: '0.85rem',
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = '#FF5733';
                    e.currentTarget.style.color = 'white';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 87, 51, 0.1)';
                    e.currentTarget.style.color = '#FF5733';
                  }}
                >
                  {chip}
                </button>
              ))}
            </div>

            <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    handleSend();
                  }
                }}
                placeholder="Type your health question here..."
                style={{
                  flex: 1,
                  background: '#0f1419',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  padding: '1rem 1.5rem',
                  borderRadius: '1rem',
                  color: '#fff',
                  outline: 'none',
                  transition: 'border-color 0.2s',
                }}
                onFocus={(e) => {
                  e.currentTarget.style.borderColor = '#FF5733';
                }}
                onBlur={(e) => {
                  e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                }}
              />
              <button
                onClick={() => handleSend()}
                disabled={isTyping}
                style={{
                  height: '50px',
                  width: '50px',
                  borderRadius: '50%',
                  padding: 0,
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  background: isTyping ? '#555' : '#FF5733',
                  border: 'none',
                  color: 'white',
                  cursor: isTyping ? 'not-allowed' : 'pointer',
                  fontSize: '1.1rem',
                  transition: 'all 0.2s',
                }}
              >
                <i className="fas fa-paper-plane"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
