import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { useStore } from '@/contexts/StoreContext';
import { toast } from 'sonner';

export default function Cart() {
  const { cart, removeFromCart, updateCartItemQuantity, getCartTotal, clearCart } = useStore();

  const subtotal = getCartTotal();
  const tax = subtotal * 0.05;
  const total = subtotal + tax;

  const handleRemove = (id: string | number) => {
    removeFromCart(id);
    toast.success('Item removed from cart');
  };

  const handleQuantityChange = (id: string | number, newQuantity: number) => {
    if (newQuantity > 0) {
      updateCartItemQuantity(id, newQuantity);
    }
  };

  if (cart.length === 0) {
    return (
      <div style={{ minHeight: '80vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>
            <i className="fas fa-shopping-basket" style={{ color: '#FF5733' }}></i>
          </div>
          <h2 style={{ marginBottom: '1rem' }}>
            Your cart is <span style={{ color: '#FF5733' }}>empty</span>
          </h2>
          <p style={{ color: '#b0b0b0', marginBottom: '2.5rem', maxWidth: '500px', margin: '0 auto 2.5rem' }}>
            It looks like you haven't added any fitness essentials to your cart yet. Start your journey now with our premium supplements and expert guidance.
          </p>
          <Link href="/shop" style={{ textDecoration: 'none' }}>
            <Button className="btn-primary">Explore Shop</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', padding: '2rem 0' }}>
      <div className="container">
        <h1 style={{ marginBottom: '2rem' }}>Shopping Cart</h1>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '2rem' }}>
          <div>
            {cart.map((item) => (
              <div
                key={item.id}
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(80px, 1fr))',
                  gap: '1.5rem',
                  padding: '1.5rem',
                  background: '#1A1F26',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '1rem',
                  marginBottom: '1rem',
                  alignItems: 'center',
                }}
              >
                <img
                  src={item.image}
                  alt={item.name}
                  style={{ width: '100px', height: '100px', objectFit: 'cover', borderRadius: '0.75rem' }}
                />

                <div>
                  <h3 style={{ marginBottom: '0.5rem' }}>{item.name}</h3>
                  <p style={{ color: '#b0b0b0', marginBottom: '1rem' }}>${item.price.toFixed(2)} each</p>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <button
                      onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                      style={{
                        background: '#161B22',
                        border: '1px solid rgba(255, 255, 255, 0.1)',
                        color: '#b0b0b0',
                        width: '30px',
                        height: '30px',
                        borderRadius: '0.5rem',
                        cursor: 'pointer',
                      }}
                    >
                      -
                    </button>
                    <span style={{ minWidth: '30px', textAlign: 'center' }}>{item.quantity}</span>
                    <button
                      onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                      style={{
                        background: '#161B22',
                        border: '1px solid rgba(255, 255, 255, 0.1)',
                        color: '#b0b0b0',
                        width: '30px',
                        height: '30px',
                        borderRadius: '0.5rem',
                        cursor: 'pointer',
                      }}
                    >
                      +
                    </button>
                  </div>
                </div>

                <div style={{ textAlign: 'right' }}>
                  <p style={{ fontSize: '1.2rem', fontWeight: 600, color: '#FF5733', marginBottom: '1rem' }}>
                    ${(item.price * item.quantity).toFixed(2)}
                  </p>
                  <button
                    onClick={() => handleRemove(item.id)}
                    style={{
                      background: 'transparent',
                      border: 'none',
                      color: '#E74C3C',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.5rem',
                    }}
                  >
                    <i className="fas fa-trash-alt"></i> Remove
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div
            style={{
              background: '#1A1F26',
              padding: '1.5rem',
              borderRadius: '1rem',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              height: 'fit-content',
              position: 'sticky',
              top: '100px',
              gridColumn: 'span 1',
            }}
          >
            <h3 style={{ marginBottom: '1.5rem' }}>Order Summary</h3>

            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem', paddingBottom: '1rem', borderBottom: '1px solid rgba(255, 255, 255, 0.1)' }}>
              <span>Subtotal</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem', paddingBottom: '1rem', borderBottom: '1px solid rgba(255, 255, 255, 0.1)' }}>
              <span>Tax (5%)</span>
              <span>${tax.toFixed(2)}</span>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem', paddingBottom: '1rem', borderBottom: '1px solid rgba(255, 255, 255, 0.1)' }}>
              <span>Shipping</span>
              <span style={{ color: '#2ECC71', fontWeight: 600 }}>Free</span>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1.5rem', fontSize: '1.1rem', fontWeight: 600 }}>
              <span>Total</span>
              <span style={{ color: '#FF5733' }}>${total.toFixed(2)}</span>
            </div>

            <Link href="/checkout" style={{ textDecoration: 'none' }}>
              <Button style={{ width: '100%', marginBottom: '1rem' }} className="btn-primary">
                Proceed to Checkout
              </Button>
            </Link>

            <Link href="/shop" style={{ textDecoration: 'none' }}>
              <Button variant="outline" style={{ width: '100%' }}>
                Continue Shopping
              </Button>
            </Link>

            <button
              onClick={() => {
                clearCart();
                toast.success('Cart cleared');
              }}
              style={{
                width: '100%',
                marginTop: '1rem',
                padding: '0.75rem',
                background: 'transparent',
                border: '1px solid rgba(255, 255, 255, 0.1)',
                color: '#E74C3C',
                borderRadius: '0.75rem',
                cursor: 'pointer',
              }}
            >
              Clear Cart
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
