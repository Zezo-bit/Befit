import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useStore, UserProfile } from '@/contexts/StoreContext';
import { toast } from 'sonner';
import ProfileHeader from './components/ProfileHeader';
import ProfileCompletion from './components/ProfileCompletion';
import HealthMetrics from './components/HealthMetrics';
import ProfileInfoCards from './components/ProfileInfoCards';
import ActivityLevelSelector from './components/ActivityLevelSelector';
import ChronicDiseaseSelector from './components/ChronicDiseaseSelector';
import RecommendationsSection from './components/RecommendationsSection';
import { Button } from '@/components/ui/button';
import { Zap } from 'lucide-react';

export default function HealthProfile() {
  const [, setLocation] = useLocation();
  const { user, updateUser, logout } = useStore();
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState<UserProfile>(user || { name: '', email: '' });

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-950 px-4 py-8">
        <div className="mb-8">
          <div className="text-8xl">❤️</div>
        </div>
        <h1 className="text-4xl md:text-5xl font-bold mb-4 text-center">Create Your Health Profile</h1>
        <p className="text-gray-400 mb-8 max-w-md text-center leading-relaxed text-lg">
          Get started with BeFit today. Sign up to create your personalized health profile and receive AI-powered supplement recommendations.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center w-full sm:w-auto">
          <Link href="/signup" className="w-full sm:w-auto">
            <Button className="btn-primary w-full py-3 text-base">
              <Zap size={18} className="mr-2" />
              Create Account
            </Button>
          </Link>
          <Link href="/login" className="w-full sm:w-auto">
            <Button variant="outline" className="w-full py-3 text-base">
              Sign In
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  // Calculate metrics
  const calculateBMI = () => {
    if (!user.weight || !user.height) return null;
    const heightInMeters = user.height / 100;
    return (user.weight / (heightInMeters * heightInMeters)).toFixed(1);
  };

  const calculateBMR = () => {
    if (!user.weight || !user.height || !user.age) return null;
    const bmr = 10 * user.weight + 6.25 * user.height - 5 * user.age + 5;
    return Math.round(bmr);
  };

  const calculateTDEE = () => {
    const bmr = calculateBMR();
    if (!bmr) return null;

    const activityMultipliers: { [key: string]: number } = {
      sedentary: 1.2,
      lightly_active: 1.375,
      moderately_active: 1.55,
      very_active: 1.725,
    };

    const multiplier = activityMultipliers[user.activityLevel as string] || 1.2;
    return Math.round(bmr * multiplier);
  };

  const getBMICategory = () => {
    const bmiStr = calculateBMI();
    if (!bmiStr) return null;
    const bmi = parseFloat(bmiStr);
    if (bmi < 18.5) return { category: 'Underweight', color: '#3498DB', bg: 'rgba(52, 152, 219, 0.1)' };
    if (bmi < 25) return { category: 'Normal', color: '#2ECC71', bg: 'rgba(46, 204, 113, 0.1)' };
    if (bmi < 30) return { category: 'Overweight', color: '#F39C12', bg: 'rgba(243, 156, 18, 0.1)' };
    return { category: 'Obese', color: '#E74C3C', bg: 'rgba(231, 76, 60, 0.1)' };
  };

  const calculateProfileCompletion = () => {
    const fields = ['name', 'age', 'weight', 'height', 'goal', 'activityLevel', 'chronicDiseases'];
    const completedFields = fields.filter((field) => {
      const value = user[field as keyof typeof user];
      return value && (Array.isArray(value) ? value.length > 0 : true);
    });
    return Math.round((completedFields.length / fields.length) * 100);
  };

  const getRecommendations = () => {
    const baseRecommendations: { [key: string]: { products: string[]; tips: string[] } } = {
      muscle_gain: {
        products: ['Whey Protein', 'Creatine Monohydrate', 'BCAAs', 'Multivitamin'],
        tips: ['Increase protein intake to 1.6-2.2g per kg', 'Focus on resistance training', 'Get 7-9 hours of sleep'],
      },
      weight_loss: {
        products: ['Green Tea Extract', 'Caffeine', 'Fiber Supplement', 'Multivitamin'],
        tips: ['Create a calorie deficit', 'Increase cardio sessions', 'Stay hydrated'],
      },
      endurance: {
        products: ['Beta-Alanine', 'Citrulline Malate', 'Electrolytes', 'Carb Powder'],
        tips: ['Build cardiovascular capacity gradually', 'Vary your training intensity', 'Proper nutrition timing'],
      },
      general_health: {
        products: ['Multivitamin', 'Omega-3', 'Vitamin D', 'Probiotic'],
        tips: ['Maintain balanced nutrition', 'Regular moderate exercise', 'Stress management'],
      },
    };

    let recommendations = baseRecommendations[user.goal as string] || baseRecommendations.general_health;

    const chronicDiseasesList = user.chronicDiseases as string[] || [];

    if (chronicDiseasesList.includes('diabetes')) {
      recommendations.products = recommendations.products.filter((p) => !['Carb Powder', 'Sugar-based'].some((exclude) => p.includes(exclude)));
      recommendations.products.push('Chromium', 'Alpha Lipoic Acid', 'Cinnamon Extract');
      recommendations.tips.push('Monitor blood sugar levels regularly', 'Limit simple carbohydrates', 'Consult with your doctor before supplements');
    }

    if (chronicDiseasesList.includes('hypertension')) {
      recommendations.products = recommendations.products.filter((p) => !['Caffeine', 'Stimulants'].some((exclude) => p.includes(exclude)));
      recommendations.products.push('Potassium', 'Magnesium', 'Hawthorn Extract');
      recommendations.tips.push('Reduce sodium intake', 'Practice stress management', 'Monitor blood pressure regularly');
    }

    if (chronicDiseasesList.includes('heart_disease')) {
      recommendations.products = recommendations.products.filter((p) => !['Stimulants', 'High Caffeine'].some((exclude) => p.includes(exclude)));
      recommendations.products.push('Omega-3 Fish Oil', 'CoQ10', 'L-Carnitine');
      recommendations.tips.push('Avoid high-sodium foods', 'Regular light exercise', 'Consult cardiologist before any supplement');
    }

    if (chronicDiseasesList.includes('thyroid')) {
      recommendations.products.push('Selenium', 'Iodine', 'L-Tyrosine');
      recommendations.tips.push('Maintain consistent supplement timing', 'Avoid soy products in excess', 'Regular thyroid function tests');
    }

    if (chronicDiseasesList.includes('kidney_disease')) {
      recommendations.products = recommendations.products.filter((p) => !['Creatine', 'High Protein'].some((exclude) => p.includes(exclude)));
      recommendations.products.push('Low-Sodium Multivitamin', 'Phosphate Binder');
      recommendations.tips.push('Limit protein intake', 'Monitor potassium levels', 'Consult nephrologist before supplements');
    }

    if (chronicDiseasesList.includes('liver_disease')) {
      recommendations.products = recommendations.products.filter((p) => !['Niacin', 'High-dose Vitamins'].some((exclude) => p.includes(exclude)));
      recommendations.products.push('Milk Thistle', 'N-Acetyl Cysteine', 'Liver Support Complex');
      recommendations.tips.push('Avoid alcohol completely', 'Limit fat intake', 'Regular liver function tests');
    }

    if (chronicDiseasesList.includes('celiac')) {
      recommendations.products = recommendations.products.filter((p) => !['Wheat-based'].some((exclude) => p.includes(exclude)));
      recommendations.products.push('Gluten-Free Protein', 'Iron Supplement', 'B12 Supplement');
      recommendations.tips.push('Strictly avoid gluten', 'Check all supplement labels for gluten', 'Monitor nutrient absorption');
    }

    if (chronicDiseasesList.includes('ibs')) {
      recommendations.products.push('Probiotic', 'Psyllium Husk', 'Peppermint Oil');
      recommendations.tips.push('Identify trigger foods', 'Increase fiber gradually', 'Stay well hydrated');
    }

    return recommendations;
  };

  const handleLogout = () => {
    logout();
    toast.success('Logged out successfully');
    setLocation('/');
  };

  const handleEditChange = (field: string, value: any) => {
    setEditData({ ...editData, [field]: value });
  };

  const handleActivityLevelChange = (level: string) => {
    handleEditChange('activityLevel', level);
  };

  const handleChronicDiseaseToggle = (disease: string) => {
    const current = editData.chronicDiseases as string[] || [];
    if (current.includes(disease)) {
      handleEditChange('chronicDiseases', current.filter((d) => d !== disease));
    } else {
      handleEditChange('chronicDiseases', [...current, disease]);
    }
  };

  const handleSaveChanges = () => {
    updateUser(editData);
    setIsEditing(false);
    toast.success('Profile updated successfully!');
  };

  const profileCompletion = calculateProfileCompletion();
  const recommendations = getRecommendations();
  const tdee = calculateTDEE();
  const bmr = calculateBMR();
  const bmi = calculateBMI();
  const bmiInfo = getBMICategory();

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <ProfileHeader
        user={user}
        isEditing={isEditing}
        onEditToggle={() => setIsEditing(!isEditing)}
        onSaveChanges={handleSaveChanges}
        onCancel={() => {
          setIsEditing(false);
          setEditData(user);
        }}
        onLogout={handleLogout}
      />

      {/* Profile Completion */}
      <ProfileCompletion completion={profileCompletion} />

      {/* Health Metrics */}
      <HealthMetrics user={user} bmi={bmi} bmiCategory={bmiInfo} bmr={bmr} tdee={tdee} />

      {/* Personal Information */}
      <ProfileInfoCards user={user} isEditing={isEditing} editData={editData} onEditChange={handleEditChange} />

      {/* Activity Level */}
      <ActivityLevelSelector isEditing={isEditing} currentLevel={isEditing ? editData.activityLevel : user.activityLevel} onActivityLevelChange={handleActivityLevelChange} />

      {/* Chronic Diseases */}
      <ChronicDiseaseSelector isEditing={isEditing} selectedDiseases={isEditing ? editData.chronicDiseases : user.chronicDiseases} onDiseaseToggle={handleChronicDiseaseToggle} />

      {/* Recommendations */}
      <RecommendationsSection products={recommendations.products} tips={recommendations.tips} />

      {/* Bottom Padding */}
      <div className="py-8" />
    </div>
  );
}
