import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { StoreProvider } from "./contexts/StoreContext";
import { Navbar } from "./components/Navbar";
import { Footer } from "./components/Footer";
import NotFound from "./pages/NotFound";
import Home from "./pages/Home";
import Shop from "./pages/Shop";
import Cart from "./pages/Cart";
import Consultation from "./pages/Consultation";
import MythVsFact from "./pages/MythVsFact";
import Community from "./pages/Community";
import HealthProfile from "./pages/HealthProfile";
import Checkout from "./pages/Checkout";
import Payment from "./pages/Payment";
import AIConsultation from "./pages/AIConsultation";
import ProductDetails from "./pages/ProductDetails";
import CreateProfile from "./pages/CreateProfile";
import Booking from "./pages/Booking";
import Login from "./pages/Login";
import Signup from "./pages/Signup";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/shop" component={Shop} />
      <Route path="/cart" component={Cart} />
      <Route path="/consultation" component={Consultation} />
      <Route path="/myth-vs-fact" component={MythVsFact} />
      <Route path="/community" component={Community} />
      <Route path="/health-profile" component={HealthProfile} />
      <Route path="/checkout" component={Checkout} />
      <Route path="/payment" component={Payment} />
      <Route path="/ai-consultation" component={AIConsultation} />
      <Route path="/product-details/:id" component={ProductDetails} />
      <Route path="/create-profile" component={CreateProfile} />
      <Route path="/booking/:id" component={Booking} />
      <Route path="/booking" component={Booking} />
      <Route path="/login" component={Login} />
      <Route path="/signup" component={Signup} />
      <Route path="/404" component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <StoreProvider>
          <TooltipProvider>
            <Toaster />
            <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
              <Navbar />
              <main style={{ flex: 1 }}>
                <Router />
              </main>
              <Footer />
            </div>
          </TooltipProvider>
        </StoreProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
