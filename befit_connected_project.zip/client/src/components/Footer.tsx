import React from 'react';
import { Link } from 'wouter';
import './Footer.css';

export const Footer: React.FC = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-section">
            <h3 className="logo !text-orange-600 font-bold" style={{ marginBottom: '1rem' }}>
              BeFit
            </h3>
            <p>Science-backed fitness e-commerce. Your safety, our priority.</p>
            <div className="social-links">
              <a href="#" title="Facebook">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" title="Twitter">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" title="Instagram">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" title="LinkedIn">
                <i className="fab fa-linkedin-in"></i>
              </a>
            </div>
          </div>

          <div className="footer-section">
            <h4>Shop</h4>
            <ul>
              <li>
                <Link href="/shop">Supplements</Link>
              </li>
              <li>
                <Link href="/shop">Equipment</Link>
              </li>
              <li>
                <Link href="/shop">Smart Bundles</Link>
              </li>
              <li>
                <Link href="/shop">New Arrivals</Link>
              </li>
            </ul>
          </div>

          <div className="footer-section">
            <h4>Resources</h4>
            <ul>
              <li>
                <a href="#">Scientific References</a>
              </li>
              <li>
                <Link href="/myth-vs-fact">Myth vs Fact Library</Link>
              </li>
              <li>
                <a href="#">Health Blog</a>
              </li>
              <li>
                <a href="#">FAQ</a>
              </li>
            </ul>
          </div>

          <div className="footer-section">
            <h4>Legal & Privacy</h4>
            <ul>
              <li>
                <a href="#">Privacy Policy</a>
              </li>
              <li>
                <a href="#">Health Data Privacy</a>
              </li>
              <li>
                <a href="#">Terms of Service</a>
              </li>
              <li>
                <a href="#">HIPAA Compliance</a>
              </li>
            </ul>
          </div>
        </div>

        <div className="footer-bottom">
          <p>&copy; 2026 BeFit. All rights reserved. Not medical advice. Consult healthcare professionals.</p>
        </div>
      </div>
    </footer>
  );
};
