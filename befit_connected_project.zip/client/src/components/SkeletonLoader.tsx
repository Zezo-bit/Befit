import React from 'react';

export function SkeletonCard() {
  return (
    <div className="bg-slate-900/50 border border-white/10 rounded-lg p-4 md:p-6 animate-pulse">
      <div className="h-4 bg-slate-800 rounded w-1/3 mb-3"></div>
      <div className="h-8 bg-slate-800 rounded w-2/3"></div>
    </div>
  );
}

export function SkeletonText({ lines = 3 }: { lines?: number }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: lines }).map((_, i) => (
        <div key={i} className="h-4 bg-slate-800 rounded animate-pulse" style={{ width: `${90 - i * 10}%` }}></div>
      ))}
    </div>
  );
}

export function SkeletonGrid({ columns = 4 }: { columns?: number }) {
  return (
    <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-${columns} gap-4`}>
      {Array.from({ length: columns }).map((_, i) => (
        <SkeletonCard key={i} />
      ))}
    </div>
  );
}

export function SkeletonProfileHeader() {
  return (
    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 flex-wrap animate-pulse">
      <div className="flex items-center gap-4 w-full md:w-auto">
        <div className="w-20 h-20 bg-slate-800 rounded-lg"></div>
        <div className="flex-1">
          <div className="h-6 bg-slate-800 rounded w-1/2 mb-2"></div>
          <div className="h-4 bg-slate-800 rounded w-2/3"></div>
        </div>
      </div>
      <div className="flex gap-2 w-full md:w-auto">
        <div className="h-10 bg-slate-800 rounded w-1/2 md:w-24"></div>
        <div className="h-10 bg-slate-800 rounded w-1/2 md:w-24"></div>
      </div>
    </div>
  );
}
