import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { useStore } from '@/contexts/StoreContext';
import { Button } from '@/components/ui/button';
import './Navbar.css';

export const Navbar: React.FC = () => {
  const [location] = useLocation();
  const { getCartItemCount, user, logout } = useStore();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.pageYOffset > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const isActive = (path: string) => {
    return location === path ? 'active' : '';
  };

  const cartCount = getCartItemCount();

  return (
    <nav className={`navbar ${scrolled ? 'scrolled' : ''}`}>
      <div className="navbar-container">
        <Link href="/" className="logo !text-orange-600 font-bold">
          BeFit
        </Link>

        <div className={`nav-center ${mobileMenuOpen ? 'active' : ''}`}>
          <Link href="/" className={`nav-link ${isActive('/')}`}>
            Home
          </Link>
          <Link href="/shop" className={`nav-link ${isActive('/shop')}`}>
            Shop
          </Link>
          <Link href="/consultation" className={`nav-link ${isActive('/consultation')}`}>
            Consultation
          </Link>
          <Link href="/myth-vs-fact" className={`nav-link ${isActive('/myth-vs-fact')}`}>
            Myth vs Fact
          </Link>
          <Link href="/community" className={`nav-link ${isActive('/community')}`}>
            Community
          </Link>
        </div>

        <div className="nav-right">
          <Link href="/cart" className="cart-btn">
            <i className="fas fa-shopping-cart"></i>
            {cartCount > 0 && <span className="cart-badge">{cartCount}</span>}
          </Link>
          {user ? (
            <div className="user-profile-nav">
              <Link href="/health-profile" className="welcome-msg">
                <i className="fas fa-heart" style={{ marginRight: '0.5rem', color: '#FF5733' }}></i>
                <span className="user-name">{user.name.split(' ')[0]}</span>
              </Link>
              <Button variant="ghost" size="sm" className="btn-logout" onClick={logout}>
                <i className="fas fa-sign-out-alt"></i>
              </Button>
            </div>
          ) : (
            <div className="auth-buttons">
              <Link href="/login">
                <Button variant="default" size="sm" className="btn-primary">
                  Login
                </Button>
              </Link>
            </div>
          )}
        </div>

        <button
          className="mobile-menu-toggle"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          <i className={`fas fa-${mobileMenuOpen ? 'times' : 'bars'}`}></i>
        </button>
      </div>
    </nav>
  );
};
