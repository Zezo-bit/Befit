import React from 'react';
import { AlertCircle, CheckCircle } from 'lucide-react';

interface FormInputProps {
  label: string;
  type?: string;
  name: string;
  value: string | number;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string;
  error?: string;
  success?: boolean;
  icon?: React.ReactNode;
  required?: boolean;
  disabled?: boolean;
}

export default function FormInput({
  label,
  type = 'text',
  name,
  value,
  onChange,
  placeholder,
  error,
  success,
  icon,
  required,
  disabled,
}: FormInputProps) {
  return (
    <div>
      <label className="block text-sm font-medium mb-2">
        {label}
        {required && <span className="text-orange-600 ml-1">*</span>}
      </label>
      <div className="relative">
        {icon && (
          <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none">
            {icon}
          </div>
        )}
        <input
          type={type}
          name={name}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          disabled={disabled}
          className={`w-full ${icon ? 'pl-10' : 'pl-4'} pr-10 py-3 bg-slate-800 border rounded-lg text-white placeholder-gray-500 focus:outline-none transition-colors ${
            error
              ? 'border-red-500 focus:border-red-500'
              : success
                ? 'border-green-500 focus:border-green-500'
                : 'border-white/10 focus:border-orange-500'
          } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
        />
        {error && (
          <AlertCircle size={18} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-red-500" />
        )}
        {success && !error && (
          <CheckCircle size={18} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-green-500" />
        )}
      </div>
      {error && <p className="text-red-500 text-xs mt-1 flex items-center gap-1">{error}</p>}
    </div>
  );
}
