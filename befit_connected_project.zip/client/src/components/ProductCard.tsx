import React from 'react';
import { useStore } from '@/contexts/StoreContext';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import './ProductCard.css';

interface ProductCardProps {
  id: string | number;
  name: string;
  price: number;
  image: string;
  description?: string;
  rating?: number;
  reviews?: number;
  safetyScore?: number;
  recommended?: boolean;
  badge?: string;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  id,
  name,
  price,
  image,
  description,
  rating = 4.8,
  reviews = 0,
  safetyScore,
  recommended,
  badge,
}) => {
  const { addToCart } = useStore();

  const handleAddToCart = () => {
    addToCart({
      id,
      name,
      price,
      image,
      quantity: 1,
    });
    toast.success(`${name} added to cart!`);
  };

  return (
    <div className="product-card">
      <div className="product-image">
        <img src={image} alt={name} />
        <div className="product-header">
          {(recommended || badge) && (
            <span className="badge-recommended">{badge || 'Recommended'}</span>
          )}
          {safetyScore && <span className="safety-score">Shield {safetyScore}</span>}
        </div>
      </div>
      <div className="product-content">
        <h3>{name}</h3>
        {description && <p className="product-desc">{description}</p>}
        {rating && (
          <div className="product-rating">
            <i className="fas fa-star"></i>
            {rating}
            {reviews > 0 && <span style={{ fontSize: '0.8rem', color: '#808080' }}>({reviews} reviews)</span>}
          </div>
        )}
        <div className="product-price">
          <span className="price">${price.toFixed(2)}</span>
        </div>
        <Button onClick={handleAddToCart} className="btn-block btn-primary" style={{ width: '100%' }}>
          Add to Cart
        </Button>
      </div>
    </div>
  );
};
