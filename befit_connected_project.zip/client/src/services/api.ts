import axios from 'axios';

const API_BASE_URL = 'http://mycreetapi.runasp.net/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add a request interceptor to include the JWT token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('befit_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export const authService = {
  register: (data: any) => api.post('/Auth/register', data),
  login: (data: any) => api.post('/Auth/login', data),
  changePassword: (data: any) => api.post('/Auth/change-password', data),
};

export const productService = {
  getAll: () => api.get('/Product/getallproducts'),
  getById: (id: any) => api.get(`/Product/getproductbyid/${id}`),
  getByCategory: (categoryId: any) => api.get(`/Product/getproductbycategory/${categoryId}`),
  search: (query: string) => api.get(`/Product/searchproduct?name=${query}`),
};

export const categoryService = {
  getAll: () => api.get('/Category/getallcategories'),
  getById: (id: any) => api.get(`/Category/getcategory/${id}`),
};

export const cartService = {
  get: () => api.get('/Cart'),
  addItem: (productId: any, quantity: number) => api.post('/Cart/add-item', { productId, quantity }),
  updateQuantity: (productId: any, quantity: number) => api.put(`/Cart/update-item-quantity/${productId}`, { quantity }),
  removeItem: (productId: any) => api.delete(`/Cart/remove-item/${productId}`),
  clear: () => api.delete('/Cart/clear'),
};

export const orderService = {
  getAll: () => api.get('/Order'),
  getById: (id: any) => api.get(`/Order/${id}`),
  create: (data: any) => api.post('/Order', data),
  updateStatus: (id: any, status: string) => api.put(`/Order/${id}/status`, { status }),
};

export default api;
