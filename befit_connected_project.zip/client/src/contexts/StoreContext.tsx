import React, { createContext, useContext, useState, useEffect } from 'react';
import { authService, productService, cartService, orderService } from '@/services/api';
import { toast } from 'sonner';

export interface CartItem {
  id: string | number;
  name: string;
  price: number;
  image: string;
  quantity: number;
  type?: 'product' | 'consultation';
  date?: string;
  time?: string;
}

export interface UserProfile {
  id?: string | number;
  name: string;
  email: string;
  password?: string;
  age?: number;
  weight?: number;
  height?: number;
  goal?: string;
  activityLevel?: string;
  chronicDiseases?: string[];
  medicalConditions?: string[];
  allergies?: string[];
  medications?: string;
  createdAt?: string;
  avatar?: string;
}

export interface Product {
  id: string | number;
  name: string;
  price: number;
  oldPrice?: number;
  image: string;
  description?: string;
  category?: string;
  rating?: number;
  reviews?: number;
  safetyScore?: number;
  recommended?: boolean;
  type?: 'product' | 'bundle';
  tags?: string[];
}

export interface Consultation {
  id: string | number;
  name: string;
  expert: string;
  specialization: string;
  price: number;
  duration: string;
  image: string;
  description: string;
  type: 'consultation';
}

interface StoreContextType {
  cart: CartItem[];
  user: UserProfile | null;
  products: Product[];
  consultations: Consultation[];
  allUsers: UserProfile[];
  
  // Cart methods
  addToCart: (product: CartItem) => void;
  removeFromCart: (productId: string | number) => void;
  updateCartItemQuantity: (productId: string | number, quantity: number) => void;
  getCartTotal: () => number;
  getCartItemCount: () => number;
  clearCart: () => void;
  
  // User methods
  setUser: (userData: UserProfile) => void;
  updateUser: (updates: Partial<UserProfile>) => void;
  logout: () => void;
  isLoggedIn: () => boolean;
  
  // Auth methods
  registerUser: (userData: UserProfile) => boolean;
  loginUser: (email: string, password: string) => boolean;
  getUserByEmail: (email: string) => UserProfile | undefined;
  
  // Consultation methods
  getConsultation: (id: string | number) => Consultation | undefined;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [user, setUserState] = useState<UserProfile | null>(null);
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [consultations] = useState<Consultation[]>([
    {
      id: 101,
      name: 'Expert Consultation - Dr. Sarah Ahmed',
      expert: 'Dr. Sarah Ahmed',
      specialization: 'Clinical Nutritionist & MD',
      price: 99.0,
      duration: '30 min',
      image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&w=150&q=80',
      description: 'Personalized consultation with Dr. Sarah Ahmed for medical-grade supplement plans',
      type: 'consultation',
    },
    {
      id: 102,
      name: 'Expert Consultation - Coach Mike Ross',
      expert: 'Coach Mike Ross',
      specialization: 'Certified Strength Coach',
      price: 99.0,
      duration: '30 min',
      image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=150&q=80',
      description: 'Personalized consultation with Coach Mike Ross for performance supplementation',
      type: 'consultation',
    },
  ]);

  // Load from API and localStorage on mount
  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        const productRes = await productService.getAll();
        setProducts(productRes.data);
      } catch (e) {
        console.error('Failed to fetch products', e);
      }

      const savedCart = localStorage.getItem('befit_cart');
      const savedUser = localStorage.getItem('befit_current_user');
      
      if (savedCart) {
        try {
          setCart(JSON.parse(savedCart));
        } catch (e) {
          console.error('Failed to load cart from localStorage', e);
        }
      }
      
      if (savedUser) {
        try {
          setUserState(JSON.parse(savedUser));
        } catch (e) {
          console.error('Failed to load user from localStorage', e);
        }
      }
    };

    fetchInitialData();
  }, []);

  // Save cart to localStorage
  useEffect(() => {
    localStorage.setItem('befit_cart', JSON.stringify(cart));
  }, [cart]);

  // Save current user to localStorage
  useEffect(() => {
    if (user) {
      localStorage.setItem('befit_current_user', JSON.stringify(user));
    }
  }, [user]);

  // Save all users to localStorage
  useEffect(() => {
    localStorage.setItem('befit_all_users', JSON.stringify(allUsers));
  }, [allUsers]);

  const fetchCart = async () => {
    try {
      const res = await cartService.get();
      // Transform backend cart items to match frontend CartItem interface if needed
      if (res.data && res.data.items) {
        setCart(res.data.items.map((item: any) => ({
          id: item.productId,
          name: item.productName,
          price: item.price,
          image: item.productImage || 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?auto=format&fit=crop&w=300&q=80',
          quantity: item.quantity
        })));
      }
    } catch (e) {
      console.error('Failed to fetch cart', e);
    }
  };

  const addToCart = async (product: CartItem) => {
    try {
      await cartService.addItem(product.id, product.quantity || 1);
      await fetchCart();
      toast.success(`${product.name} added to cart!`);
    } catch (e) {
      // Fallback to local state if not logged in or API fails
      setCart((prevCart) => {
        const existing = prevCart.find((item) => item.id === product.id);
        if (existing) {
          return prevCart.map((item) =>
            item.id === product.id
              ? { ...item, quantity: item.quantity + (product.quantity || 1) }
              : item
          );
        }
        return [...prevCart, { ...product, quantity: product.quantity || 1 }];
      });
      toast.success(`${product.name} added to local cart!`);
    }
  };

  const removeFromCart = async (productId: string | number) => {
    try {
      await cartService.removeItem(productId);
      await fetchCart();
    } catch (e) {
      setCart((prevCart) => prevCart.filter((item) => item.id !== productId));
    }
  };

  const updateCartItemQuantity = async (productId: string | number, quantity: number) => {
    try {
      await cartService.updateQuantity(productId, quantity);
      await fetchCart();
    } catch (e) {
      setCart((prevCart) =>
        prevCart.map((item) =>
          item.id === productId ? { ...item, quantity: Math.max(1, quantity) } : item
        )
      );
    }
  };

  const getCartTotal = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  const getCartItemCount = () => {
    return cart.reduce((count, item) => count + item.quantity, 0);
  };

  const clearCart = async () => {
    try {
      await cartService.clear();
      setCart([]);
    } catch (e) {
      setCart([]);
    }
  };

  const setUser = (userData: UserProfile) => {
    setUserState({
      ...userData,
      id: userData.id || Date.now(),
      createdAt: userData.createdAt || new Date().toISOString(),
    });
  };

  const updateUser = (updates: Partial<UserProfile>) => {
    setUserState((prevUser) => {
      if (!prevUser) return null;
      const updatedUser = { ...prevUser, ...updates };
      // Update in allUsers array
      setAllUsers((prevUsers) =>
        prevUsers.map((u) => (u.id === prevUser.id ? updatedUser : u))
      );
      return updatedUser;
    });
  };

  const logout = () => {
    setUserState(null);
    localStorage.removeItem('befit_current_user');
  };

  const isLoggedIn = () => {
    return user !== null;
  };

  const registerUser = async (userData: any): Promise<boolean> => {
    try {
      const res = await authService.register(userData);
      if (res.status === 200 || res.status === 201) {
        return true;
      }
      return false;
    } catch (e: any) {
      toast.error(e.response?.data?.message || 'Registration failed');
      return false;
    }
  };

  const loginUser = async (email: string, password: string): Promise<boolean> => {
    try {
      const res = await authService.login({ email, password });
      if (res.data.token) {
        localStorage.setItem('befit_token', res.data.token);
        setUserState(res.data.user || { email });
        return true;
      }
      return false;
    } catch (e: any) {
      toast.error(e.response?.data?.message || 'Login failed');
      return false;
    }
  };

  const getUserByEmail = (email: string): UserProfile | undefined => {
    return allUsers.find((u) => u.email === email);
  };

  const getConsultation = (id: string | number) => {
    return consultations.find((c) => c.id === id);
  };

  const value: StoreContextType = {
    cart,
    user,
    products,
    consultations,
    allUsers,
    addToCart,
    removeFromCart,
    updateCartItemQuantity,
    getCartTotal,
    getCartItemCount,
    clearCart,
    setUser,
    updateUser,
    logout,
    isLoggedIn,
    registerUser,
    loginUser,
    getUserByEmail,
    getConsultation,
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
